"""PyQt6 GUI components for OpenNucFold."""
