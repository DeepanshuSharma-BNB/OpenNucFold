"""Tab 1 — Single Strand Folding: MFE + partition function + dot plot."""

from __future__ import annotations

import json
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QTabWidget,
    QLabel, QLineEdit, QPlainTextEdit, QMessageBox, QFileDialog,
)

from opennucfold.backends.manager import BackendManager
from opennucfold.gui.widgets import (
    SequenceEditor, ParamsPanel, ResultText, RunButton, ExportBar, MONO_FONT,
)
from opennucfold.gui.plots import DotPlotWidget
from opennucfold.gui.workers import SingleFoldWorker
from opennucfold.models import AnalysisReport, FoldingParams, SingleFoldResult
from opennucfold.utils.sequences import validate_sequence, clean_sequence


DEMO_RNA = "GGGAAACCCUUUAAAGGGCCCUUUGGG"
DEMO_DNA = "GGGAAACCCTTTAAAGGGCCCTTTGGG"


class SingleFoldTab(QWidget):
    """Single strand MFE folding + partition function tab."""

    def __init__(self, backend_mgr: BackendManager, parent=None):
        super().__init__(parent)
        self.backend_mgr = backend_mgr
        self._worker = None
        self._result: SingleFoldResult | None = None
        self._build_ui()

    def _build_ui(self):
        main = QHBoxLayout(self)

        # Left panel: inputs
        left = QVBoxLayout()

        self.seq_editor = SequenceEditor("Sequence")
        left.addWidget(self.seq_editor)

        # Constraint input
        self.constraint_edit = QLineEdit()
        self.constraint_edit.setFont(MONO_FONT)
        self.constraint_edit.setPlaceholderText(
            "Optional: dot-bracket constraint (x = unpaired, | = paired, . = any)")
        left.addWidget(QLabel("Structure Constraint:"))
        left.addWidget(self.constraint_edit)

        self.params = ParamsPanel()
        self.params.cmb_mol.currentIndexChanged.connect(
            lambda: self.seq_editor.set_molecule(self.params.get_molecule()))
        left.addWidget(self.params)

        self.run_btn = RunButton()
        self.run_btn.run_clicked.connect(self._run)
        self.run_btn.cancel_clicked.connect(self._cancel)
        left.addWidget(self.run_btn)

        # Demo button
        from PyQt6.QtWidgets import QPushButton
        btn_demo = QPushButton("Load Demo Sequence")
        btn_demo.clicked.connect(self._load_demo)
        left.addWidget(btn_demo)

        left.addStretch()

        # Export
        self.export_bar = ExportBar()
        self.export_bar.btn_json.clicked.connect(self._export_json)
        self.export_bar.btn_png.clicked.connect(self._export_png)
        self.export_bar.btn_svg.clicked.connect(self._export_svg)
        left.addWidget(self.export_bar)

        left_w = QWidget()
        left_w.setLayout(left)

        # Right panel: results
        right = QVBoxLayout()

        self.result_text = ResultText("Structure & Energy")
        right.addWidget(self.result_text)

        # Plot tabs
        self.plot_tabs = QTabWidget()
        self.dotplot = DotPlotWidget()
        self.ppplot = DotPlotWidget()  # re-use for per-base pairing probs
        self.plot_tabs.addTab(self.dotplot, "Dot Plot")
        self.plot_tabs.addTab(self.ppplot, "Pairing Prob.")
        right.addWidget(self.plot_tabs)

        right_w = QWidget()
        right_w.setLayout(right)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_w)
        splitter.addWidget(right_w)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        main.addWidget(splitter)

    def _load_demo(self):
        from opennucfold.models import MoleculeType
        if self.params.get_molecule() == MoleculeType.DNA:
            self.seq_editor.set_sequence(DEMO_DNA)
        else:
            self.seq_editor.set_sequence(DEMO_RNA)

    def _run(self):
        seq = self.seq_editor.get_sequence()
        params = self.params.get_params()

        ok, msg = validate_sequence(seq, params.molecule)
        if not ok:
            QMessageBox.warning(self, "Invalid Sequence", msg)
            return

        backend = self.backend_mgr.primary()
        if not backend:
            QMessageBox.critical(self, "No Backend",
                                 "No folding backend is available.\n"
                                 "Please install ViennaRNA.")
            return

        # Constraints
        constraint = self.constraint_edit.text().strip()
        if constraint:
            params.constraints = constraint

        self.result_text.clear()
        self.run_btn.set_running(True)

        self._worker = SingleFoldWorker(seq, params, backend, do_partition=True)
        self._worker.progress.connect(self.run_btn.set_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _cancel(self):
        if self._worker:
            self._worker.cancel()
            self._worker.quit()
            self.run_btn.set_running(False)

    def _on_finished(self, result: SingleFoldResult):
        self.run_btn.set_running(False)
        self._result = result

        lines = [
            f"Sequence:  {result.sequence}",
            f"Structure: {result.mfe_structure}",
            f"MFE ΔG:    {result.mfe_energy:.2f} kcal/mol",
        ]
        if result.ensemble_energy:
            lines.append(f"Ensemble ΔG: {result.ensemble_energy:.2f} kcal/mol")
        if result.ensemble_diversity:
            lines.append(f"Ensemble Diversity: {result.ensemble_diversity:.2f}")
        lines.append(f"\nBackend: {result.backend} {result.backend_version}")

        self.result_text.set_text("\n".join(lines))

        # Dot plot
        if result.base_pair_probs:
            self.dotplot.plot_bpp(result.base_pair_probs, len(result.sequence))
        else:
            self.dotplot.figure.clear()
            ax = self.dotplot.figure.add_subplot(111)
            ax.text(0.5, 0.5, "No base-pair probability data\n(run with partition function)",
                    ha="center", va="center", transform=ax.transAxes, color="gray")
            self.dotplot.canvas.draw()

        # Pairing probability bar chart
        if result.pairing_probs:
            self.ppplot.plot_pairing_probs(result.pairing_probs)

        # Enable exports
        for btn in (self.export_bar.btn_json, self.export_bar.btn_png,
                    self.export_bar.btn_svg):
            btn.setEnabled(True)

    def _on_error(self, msg: str):
        self.run_btn.set_running(False)
        QMessageBox.critical(self, "Folding Error", msg)

    def _export_json(self):
        if not self._result:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save JSON Report", "single_fold_report.json",
            "JSON Files (*.json)")
        if path:
            report = AnalysisReport("single_fold", self._result, self._result.params)
            report.save(path)

    def _export_png(self):
        self.dotplot.export_png()

    def _export_svg(self):
        self.dotplot.export_svg()
