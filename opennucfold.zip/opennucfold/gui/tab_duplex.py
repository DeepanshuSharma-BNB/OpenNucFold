"""Tab 2 — Duplex / Co-folding: heterodimer, self-folds, binding risk, Tm."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QLabel,
    QMessageBox, QFileDialog, QFrame, QPushButton,
)

from opennucfold.backends.manager import BackendManager
from opennucfold.gui.widgets import (
    SequenceEditor, ParamsPanel, ResultText, RunButton, ExportBar, MONO_FONT,
)
from opennucfold.gui.workers import DuplexWorker
from opennucfold.models import AnalysisReport, DuplexResult, MoleculeType
from opennucfold.utils.sequences import validate_sequence


DEMO_A = "GCAUCCGAUAGCUAG"
DEMO_B = "CUAGCUAUCGGAUGC"


class DuplexTab(QWidget):
    """Duplex / co-folding analysis tab."""

    def __init__(self, backend_mgr: BackendManager, parent=None):
        super().__init__(parent)
        self.backend_mgr = backend_mgr
        self._worker = None
        self._result: DuplexResult | None = None
        self._build_ui()

    def _build_ui(self):
        main = QHBoxLayout(self)

        # Left: inputs
        left = QVBoxLayout()

        self.seq_a = SequenceEditor("Strand A")
        self.seq_b = SequenceEditor("Strand B")
        left.addWidget(self.seq_a)
        left.addWidget(self.seq_b)

        self.params = ParamsPanel()
        self.params.cmb_mol.currentIndexChanged.connect(self._mol_changed)
        left.addWidget(self.params)

        # DNA note
        self.dna_note = QLabel("")
        self.dna_note.setWordWrap(True)
        self.dna_note.setStyleSheet("color: #b45309; font-size: 11px;")
        left.addWidget(self.dna_note)

        self.run_btn = RunButton()
        self.run_btn.run_clicked.connect(self._run)
        self.run_btn.cancel_clicked.connect(self._cancel)
        left.addWidget(self.run_btn)

        btn_demo = QPushButton("Load Demo Strands")
        btn_demo.clicked.connect(self._load_demo)
        left.addWidget(btn_demo)

        left.addStretch()

        self.export_bar = ExportBar()
        self.export_bar.btn_json.clicked.connect(self._export_json)
        left.addWidget(self.export_bar)

        left_w = QWidget()
        left_w.setLayout(left)

        # Right: results
        right = QVBoxLayout()

        # Binding risk indicator
        self.risk_frame = QFrame()
        self.risk_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.risk_frame.setMinimumHeight(60)
        risk_layout = QVBoxLayout(self.risk_frame)
        self.risk_label = QLabel("Binding Risk: —")
        self.risk_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.risk_label.setStyleSheet("font-size: 16px; font-weight: bold;")
        risk_layout.addWidget(self.risk_label)
        self.risk_detail = QLabel("")
        self.risk_detail.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.risk_detail.setWordWrap(True)
        risk_layout.addWidget(self.risk_detail)
        right.addWidget(self.risk_frame)

        # Result panels
        self.res_cofold = ResultText("Heterodimer (Co-fold)")
        self.res_self_a = ResultText("Self-fold Strand A")
        self.res_self_b = ResultText("Self-fold Strand B")
        self.res_tm = ResultText("Tm & Summary")

        right.addWidget(self.res_cofold)

        self_splitter = QSplitter(Qt.Orientation.Horizontal)
        self_splitter.addWidget(self.res_self_a)
        self_splitter.addWidget(self.res_self_b)
        right.addWidget(self_splitter)

        right.addWidget(self.res_tm)

        right_w = QWidget()
        right_w.setLayout(right)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_w)
        splitter.addWidget(right_w)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        main.addWidget(splitter)

    def _mol_changed(self):
        mol = self.params.get_molecule()
        self.seq_a.set_molecule(mol)
        self.seq_b.set_molecule(mol)
        if mol == MoleculeType.DNA:
            has_unafold = self.backend_mgr.unafold is not None
            note = "DNA mode: ViennaRNA DNA parameters will be used."
            if has_unafold:
                note += " UNAFold available for Tm estimation."
            else:
                note += " UNAFold not found — Tm will use simple formula (approximate)."
            self.dna_note.setText(note)
        else:
            self.dna_note.setText("")

    def _load_demo(self):
        self.seq_a.set_sequence(DEMO_A)
        self.seq_b.set_sequence(DEMO_B)

    def _run(self):
        sa = self.seq_a.get_sequence()
        sb = self.seq_b.get_sequence()
        params = self.params.get_params()

        for label, seq in [("Strand A", sa), ("Strand B", sb)]:
            ok, msg = validate_sequence(seq, params.molecule)
            if not ok:
                QMessageBox.warning(self, f"Invalid {label}", msg)
                return

        backend = self.backend_mgr.best_for_duplex(params)
        if not backend:
            QMessageBox.critical(self, "No Backend",
                                 "No folding backend available.")
            return

        tm_backend = self.backend_mgr.unafold
        self.run_btn.set_running(True)
        for w in (self.res_cofold, self.res_self_a, self.res_self_b, self.res_tm):
            w.clear()

        self._worker = DuplexWorker(sa, sb, params, backend, tm_backend)
        self._worker.progress.connect(self.run_btn.set_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _cancel(self):
        if self._worker:
            self._worker.cancel()
            self._worker.quit()
            self.run_btn.set_running(False)

    def _on_finished(self, result: DuplexResult):
        self.run_btn.set_running(False)
        self._result = result

        self.res_cofold.set_text(
            f"Structure: {result.cofold_structure}\n"
            f"ΔG:        {result.cofold_energy:.2f} kcal/mol"
        )

        self.res_self_a.set_text(
            f"Structure: {result.self_a_structure}\n"
            f"ΔG:        {result.self_a_energy:.2f} kcal/mol"
        )

        self.res_self_b.set_text(
            f"Structure: {result.self_b_structure}\n"
            f"ΔG:        {result.self_b_energy:.2f} kcal/mol"
        )

        tm_lines = []
        if result.tm_estimate is not None:
            tm_lines.append(f"Estimated Tm: {result.tm_estimate:.1f} °C")
            tm_lines.append(f"Method: {result.tm_method}")
        tm_lines.append(f"\nBackend: {result.backend} {result.backend_version}")
        self.res_tm.set_text("\n".join(tm_lines))

        # Binding risk indicator
        if result.binding_favorable:
            self.risk_label.setText("✓ Heterodimer is Thermodynamically Favorable")
            self.risk_frame.setStyleSheet("background-color: #dcfce7; border-radius: 6px;")
            self.risk_detail.setText(
                f"Cofold ΔG ({result.cofold_energy:.1f}) < "
                f"self-fold A ({result.self_a_energy:.1f}) and "
                f"self-fold B ({result.self_b_energy:.1f})"
            )
        else:
            self.risk_label.setText("⚠ Self-folding May Compete with Heterodimer")
            self.risk_frame.setStyleSheet("background-color: #fef3c7; border-radius: 6px;")
            min_self = min(result.self_a_energy, result.self_b_energy)
            self.risk_detail.setText(
                f"Cofold ΔG ({result.cofold_energy:.1f}) ≥ "
                f"best self-fold ({min_self:.1f}) — binding may be weak"
            )

        self.export_bar.btn_json.setEnabled(True)

    def _on_error(self, msg: str):
        self.run_btn.set_running(False)
        QMessageBox.critical(self, "Analysis Error", msg)

    def _export_json(self):
        if not self._result:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save JSON Report", "duplex_report.json",
            "JSON Files (*.json)")
        if path:
            report = AnalysisReport("duplex", self._result, self._result.params)
            report.save(path)
