"""Matplotlib-based plotting widgets for base-pair probability dot plots
and other scientific visualizations.
"""

from __future__ import annotations

import numpy as np
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QFileDialog


class DotPlotWidget(QWidget):
    """Interactive base-pair probability dot plot with zoom/pan and export."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.figure = Figure(figsize=(5, 5), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        self.toolbar = NavToolbar(self.canvas, self)

        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)

    def plot_bpp(self, bpp: list[tuple], seq_len: int, title: str = "Base-Pair Probabilities"):
        """Plot base-pair probability matrix as a dot plot.

        Parameters
        ----------
        bpp : list of (i, j, probability)  — 1-indexed
        seq_len : length of sequence
        title : plot title
        """
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        if not bpp:
            ax.text(0.5, 0.5, "No data", ha="center", va="center",
                    transform=ax.transAxes, fontsize=14, color="gray")
            self.canvas.draw()
            return

        # Build matrix
        mat = np.zeros((seq_len, seq_len))
        for i, j, p in bpp:
            if 1 <= i <= seq_len and 1 <= j <= seq_len:
                mat[i - 1, j - 1] = p
                mat[j - 1, i - 1] = p

        # Upper triangle as dot sizes
        xs, ys, sizes, colors = [], [], [], []
        for i in range(seq_len):
            for j in range(i + 1, seq_len):
                p = mat[i, j]
                if p > 0.001:
                    xs.append(j + 1)
                    ys.append(i + 1)
                    sizes.append(p * 60)
                    colors.append(p)

        if xs:
            sc = ax.scatter(xs, ys, s=sizes, c=colors, cmap="YlOrRd",
                            vmin=0, vmax=1, alpha=0.8, edgecolors="none")
            self.figure.colorbar(sc, ax=ax, label="Probability", shrink=0.7)

        ax.set_xlim(0.5, seq_len + 0.5)
        ax.set_ylim(seq_len + 0.5, 0.5)
        ax.set_xlabel("Position j")
        ax.set_ylabel("Position i")
        ax.set_title(title, fontsize=11)
        ax.set_aspect("equal")

        # Diagonal
        ax.plot([0.5, seq_len + 0.5], [0.5, seq_len + 0.5],
                "k-", linewidth=0.5, alpha=0.3)

        self.figure.tight_layout()
        self.canvas.draw()

    def plot_pairing_probs(self, probs: list[float], title: str = "Per-Base Pairing Probability"):
        """Bar chart of per-base pairing probabilities."""
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        if not probs:
            ax.text(0.5, 0.5, "No data", ha="center", va="center",
                    transform=ax.transAxes, fontsize=14, color="gray")
            self.canvas.draw()
            return

        n = len(probs)
        positions = np.arange(1, n + 1)
        colors = ["#2563eb" if p > 0.5 else "#93c5fd" for p in probs]
        ax.bar(positions, probs, color=colors, width=1.0, edgecolor="none")
        ax.set_xlim(0.5, n + 0.5)
        ax.set_ylim(0, 1.05)
        ax.set_xlabel("Position")
        ax.set_ylabel("Pairing Probability")
        ax.set_title(title, fontsize=11)
        ax.axhline(0.5, color="gray", linestyle="--", linewidth=0.5, alpha=0.5)
        self.figure.tight_layout()
        self.canvas.draw()

    def export_png(self, path: str = ""):
        if not path:
            path, _ = QFileDialog.getSaveFileName(
                self, "Export PNG", "plot.png", "PNG Files (*.png)")
        if path:
            self.figure.savefig(path, dpi=200, bbox_inches="tight")

    def export_svg(self, path: str = ""):
        if not path:
            path, _ = QFileDialog.getSaveFileName(
                self, "Export SVG", "plot.svg", "SVG Files (*.svg)")
        if path:
            self.figure.savefig(path, format="svg", bbox_inches="tight")
