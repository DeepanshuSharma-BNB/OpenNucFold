"""Main application window for OpenNucFold."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction, QFont
from PyQt6.QtWidgets import (
    QMainWindow, QTabWidget, QStatusBar, QLabel, QMenuBar,
    QMessageBox, QApplication,
)

from opennucfold.backends.manager import BackendManager
from opennucfold.gui.tab_single import SingleFoldTab
from opennucfold.gui.tab_duplex import DuplexTab
from opennucfold.gui.tab_mixture import MixtureTab
from opennucfold.gui.tab_design import DesignTab


class MainWindow(QMainWindow):
    """OpenNucFold main window with tabbed interface."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("OpenNucFold — Nucleic Acid Folding & Design")
        self.setMinimumSize(1100, 750)

        # Backend manager
        self.backend_mgr = BackendManager()

        # Central widget — tabs
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.setCentralWidget(self.tabs)

        self.tab_single = SingleFoldTab(self.backend_mgr)
        self.tab_duplex = DuplexTab(self.backend_mgr)
        self.tab_mixture = MixtureTab(self.backend_mgr)
        self.tab_design = DesignTab(self.backend_mgr)

        self.tabs.addTab(self.tab_single, "① Single Strand")
        self.tabs.addTab(self.tab_duplex, "② Duplex / Co-fold")
        self.tabs.addTab(self.tab_mixture, "③ Mixture Analysis")
        self.tabs.addTab(self.tab_design, "④ Sequence Design")

        # Menu bar
        self._build_menu()

        # Status bar with backend info
        self.statusBar().showMessage("Ready")
        self.backend_label = QLabel()
        self.backend_label.setStyleSheet("padding-right: 10px;")
        self.statusBar().addPermanentWidget(self.backend_label)
        self._update_backend_status()

    def _build_menu(self):
        menu = self.menuBar()

        # File menu
        file_menu = menu.addMenu("&File")
        act_quit = QAction("&Quit", self)
        act_quit.setShortcut("Ctrl+Q")
        act_quit.triggered.connect(QApplication.quit)
        file_menu.addAction(act_quit)

        # Tools menu
        tools_menu = menu.addMenu("&Tools")
        act_refresh = QAction("&Refresh Backends", self)
        act_refresh.triggered.connect(self._refresh_backends)
        tools_menu.addAction(act_refresh)

        act_status = QAction("Backend &Status…", self)
        act_status.triggered.connect(self._show_backend_status)
        tools_menu.addAction(act_status)

        # Help menu
        help_menu = menu.addMenu("&Help")
        act_about = QAction("&About", self)
        act_about.triggered.connect(self._show_about)
        help_menu.addAction(act_about)

    def _update_backend_status(self):
        avail = self.backend_mgr.available()
        if avail:
            parts = [f"{k} {v}" for k, v in avail.items()]
            self.backend_label.setText("Backends: " + " | ".join(parts))
            self.backend_label.setStyleSheet("color: #166534; padding-right: 10px;")
        else:
            self.backend_label.setText("⚠ No backends found — install ViennaRNA")
            self.backend_label.setStyleSheet("color: #dc2626; padding-right: 10px;")

    def _refresh_backends(self):
        self.backend_mgr.refresh()
        self._update_backend_status()
        QMessageBox.information(
            self, "Backends Refreshed",
            self.backend_mgr.status_text())

    def _show_backend_status(self):
        QMessageBox.information(
            self, "Backend Status",
            self.backend_mgr.status_text())

    def _show_about(self):
        QMessageBox.about(
            self, "About OpenNucFold",
            "<h2>OpenNucFold v1.0.0</h2>"
            "<p>Open-source nucleic acid folding &amp; design toolkit.</p>"
            "<p>Provides NUPACK-like analysis workflows using ViennaRNA "
            "and optionally UNAFold as backends.</p>"
            "<p><b>Backends:</b></p>"
            f"<pre>{self.backend_mgr.status_text()}</pre>"
            "<p><i>All computations run locally — no internet required.</i></p>"
        )
