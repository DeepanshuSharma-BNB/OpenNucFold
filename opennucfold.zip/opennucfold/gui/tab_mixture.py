"""Tab 3 — Multi-Strand Mixture: approximate equilibrium complex concentrations."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QLabel,
    QMessageBox, QFileDialog, QPushButton, QSpinBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QDoubleSpinBox,
    QGroupBox, QGridLayout, QLineEdit, QPlainTextEdit,
    QAbstractItemView,
)

from opennucfold.backends.manager import BackendManager
from opennucfold.gui.widgets import ParamsPanel, RunButton, MONO_FONT
from opennucfold.gui.workers import MixtureWorker
from opennucfold.models import (
    AnalysisReport, MixtureResult, StrandInput, FoldingParams, MoleculeType,
)
from opennucfold.utils.sequences import validate_sequence


class StrandRow(QWidget):
    """Single strand input row: name, sequence, concentration."""

    def __init__(self, index: int, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.lbl = QLabel(f"S{index + 1}")
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText(f"Name")
        self.name_edit.setMaximumWidth(100)
        self.seq_edit = QLineEdit()
        self.seq_edit.setFont(MONO_FONT)
        self.seq_edit.setPlaceholderText("Sequence")
        self.conc_spin = QDoubleSpinBox()
        self.conc_spin.setRange(0.001, 1e6)
        self.conc_spin.setValue(1.0)
        self.conc_spin.setDecimals(3)
        self.conc_spin.setSuffix(" µM")

        layout.addWidget(self.lbl)
        layout.addWidget(self.name_edit)
        layout.addWidget(self.seq_edit, stretch=3)
        layout.addWidget(self.conc_spin)

    def get_strand(self) -> StrandInput | None:
        seq = self.seq_edit.text().strip().upper()
        if not seq:
            return None
        name = self.name_edit.text().strip() or self.lbl.text()
        return StrandInput(name=name, sequence=seq, concentration=self.conc_spin.value())


class MixtureTab(QWidget):
    """Multi-strand mixture analysis tab."""

    def __init__(self, backend_mgr: BackendManager, parent=None):
        super().__init__(parent)
        self.backend_mgr = backend_mgr
        self._worker = None
        self._result: MixtureResult | None = None
        self._build_ui()

    def _build_ui(self):
        main = QHBoxLayout(self)

        # Left: inputs
        left = QVBoxLayout()

        # Strand inputs
        strand_group = QGroupBox("Strands (up to 8)")
        strand_layout = QVBoxLayout(strand_group)
        self.strand_rows: list[StrandRow] = []
        for i in range(8):
            row = StrandRow(i)
            self.strand_rows.append(row)
            strand_layout.addWidget(row)
            if i >= 2:
                row.setVisible(False)

        btn_row = QHBoxLayout()
        self.btn_add = QPushButton("+ Add Strand")
        self.btn_add.clicked.connect(self._add_strand)
        self.btn_remove = QPushButton("− Remove Last")
        self.btn_remove.clicked.connect(self._remove_strand)
        btn_row.addWidget(self.btn_add)
        btn_row.addWidget(self.btn_remove)
        btn_row.addStretch()
        strand_layout.addLayout(btn_row)
        left.addWidget(strand_group)

        self._visible_count = 2

        # Max complex size
        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Max complex size:"))
        self.spn_size = QSpinBox()
        self.spn_size.setRange(2, 4)
        self.spn_size.setValue(2)
        size_row.addWidget(self.spn_size)
        size_row.addStretch()
        left.addLayout(size_row)

        self.params = ParamsPanel()
        left.addWidget(self.params)

        # Disclaimer
        disc = QLabel(
            "⚠ Approximate method: uses Boltzmann-weighted cofold ΔG, "
            "NOT full partition-function enumeration like NUPACK."
        )
        disc.setWordWrap(True)
        disc.setStyleSheet("color: #b45309; font-size: 11px; padding: 4px;")
        left.addWidget(disc)

        self.run_btn = RunButton()
        self.run_btn.run_clicked.connect(self._run)
        self.run_btn.cancel_clicked.connect(self._cancel)
        left.addWidget(self.run_btn)

        btn_demo = QPushButton("Load Demo Strands")
        btn_demo.clicked.connect(self._load_demo)
        left.addWidget(btn_demo)

        left.addStretch()

        btn_export = QPushButton("Export JSON")
        btn_export.clicked.connect(self._export_json)
        self.btn_export = btn_export
        btn_export.setEnabled(False)
        left.addWidget(btn_export)

        left_w = QWidget()
        left_w.setLayout(left)

        # Right: results
        right = QVBoxLayout()

        # Result table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(
            ["Complex", "ΔG (kcal/mol)", "Fraction (%)", "Est. Conc. (µM)", "Structure"])
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        right.addWidget(self.table)

        # Filter
        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("Show complexes above:"))
        self.spn_filter = QDoubleSpinBox()
        self.spn_filter.setRange(0.0, 100.0)
        self.spn_filter.setValue(0.1)
        self.spn_filter.setSuffix(" %")
        self.spn_filter.setDecimals(2)
        self.spn_filter.valueChanged.connect(self._apply_filter)
        filter_row.addWidget(self.spn_filter)
        filter_row.addStretch()
        right.addLayout(filter_row)

        # Warnings
        self.warnings_text = QPlainTextEdit()
        self.warnings_text.setReadOnly(True)
        self.warnings_text.setMaximumHeight(100)
        self.warnings_text.setFont(MONO_FONT)
        right.addWidget(QLabel("Warnings:"))
        right.addWidget(self.warnings_text)

        right_w = QWidget()
        right_w.setLayout(right)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_w)
        splitter.addWidget(right_w)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        main.addWidget(splitter)

    def _add_strand(self):
        if self._visible_count < 8:
            self.strand_rows[self._visible_count].setVisible(True)
            self._visible_count += 1

    def _remove_strand(self):
        if self._visible_count > 2:
            self._visible_count -= 1
            row = self.strand_rows[self._visible_count]
            row.setVisible(False)
            row.seq_edit.clear()
            row.name_edit.clear()

    def _load_demo(self):
        demos = [
            ("Probe", "GCAUCCGAUAGCUAG", 1.0),
            ("Target", "CUAGCUAUCGGAUGC", 0.5),
            ("Blocker", "GAUGCAAAUCCC", 2.0),
        ]
        for i, (name, seq, conc) in enumerate(demos):
            if i < 8:
                self.strand_rows[i].name_edit.setText(name)
                self.strand_rows[i].seq_edit.setText(seq)
                self.strand_rows[i].conc_spin.setValue(conc)
                self.strand_rows[i].setVisible(True)
        self._visible_count = max(self._visible_count, len(demos))

    def _run(self):
        params = self.params.get_params()
        strands = []
        for i in range(self._visible_count):
            s = self.strand_rows[i].get_strand()
            if s:
                ok, msg = validate_sequence(s.sequence, params.molecule)
                if not ok:
                    QMessageBox.warning(self, f"Invalid Strand {s.name}", msg)
                    return
                strands.append(s)

        if len(strands) < 2:
            QMessageBox.warning(self, "Need More Strands",
                                "Please enter at least 2 strands.")
            return

        backend = self.backend_mgr.primary()
        if not backend:
            QMessageBox.critical(self, "No Backend",
                                 "No folding backend available.")
            return

        self.run_btn.set_running(True)
        self.table.setRowCount(0)
        self.warnings_text.clear()

        self._worker = MixtureWorker(
            strands, self.spn_size.value(), params, backend)
        self._worker.progress.connect(self.run_btn.set_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _cancel(self):
        if self._worker:
            self._worker.cancel()
            self._worker.quit()
            self.run_btn.set_running(False)

    def _on_finished(self, result: MixtureResult):
        self.run_btn.set_running(False)
        self._result = result

        self._populate_table(result)
        self.warnings_text.setPlainText("\n".join(result.warnings))
        self.btn_export.setEnabled(True)

    def _populate_table(self, result: MixtureResult):
        threshold = self.spn_filter.value()
        filtered = [c for c in result.complexes if c.fraction * 100 >= threshold]

        self.table.setRowCount(len(filtered))
        for row, cx in enumerate(filtered):
            self.table.setItem(row, 0, QTableWidgetItem(cx.stoichiometry))
            self.table.setItem(row, 1, QTableWidgetItem(f"{cx.delta_g:.2f}"))
            self.table.setItem(row, 2, QTableWidgetItem(f"{cx.fraction*100:.2f}"))
            self.table.setItem(row, 3, QTableWidgetItem(f"{cx.concentration:.4f}"))
            struct_item = QTableWidgetItem(cx.structure[:40] + "…" if len(cx.structure) > 40 else cx.structure)
            struct_item.setToolTip(cx.structure)
            self.table.setItem(row, 4, struct_item)

    def _apply_filter(self):
        if self._result:
            self._populate_table(self._result)

    def _on_error(self, msg: str):
        self.run_btn.set_running(False)
        QMessageBox.critical(self, "Analysis Error", msg)

    def _export_json(self):
        if not self._result:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save JSON Report", "mixture_report.json",
            "JSON Files (*.json)")
        if path:
            report = AnalysisReport("mixture", self._result, self._result.params)
            report.save(path)
