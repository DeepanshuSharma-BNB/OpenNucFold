"""Reusable GUI widgets for OpenNucFold."""

from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QTextCharFormat, QColor, QIntValidator, QDoubleValidator
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QTextEdit, QPlainTextEdit,
    QComboBox, QDoubleSpinBox, QSpinBox, QPushButton,
    QGroupBox, QProgressBar, QSplitter, QApplication,
    QFileDialog, QMessageBox, QCheckBox,
)

from opennucfold.models import MoleculeType, FoldingParams
from opennucfold.utils.sequences import clean_sequence, validate_sequence, gc_content

MONO_FONT = QFont("Courier New", 10)
MONO_FONT.setStyleHint(QFont.StyleHint.Monospace)


class SequenceEditor(QGroupBox):
    """Sequence input with validation, length, and GC% display."""

    sequence_changed = pyqtSignal()

    def __init__(self, title: str = "Sequence", parent=None):
        super().__init__(title, parent)
        layout = QVBoxLayout(self)

        self.text_edit = QPlainTextEdit()
        self.text_edit.setFont(MONO_FONT)
        self.text_edit.setMaximumHeight(100)
        self.text_edit.setPlaceholderText("Paste sequence (FASTA OK)…")
        self.text_edit.textChanged.connect(self._on_changed)
        layout.addWidget(self.text_edit)

        info_row = QHBoxLayout()
        self.lbl_len = QLabel("Length: 0")
        self.lbl_gc = QLabel("GC: —")
        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color: red;")
        info_row.addWidget(self.lbl_len)
        info_row.addWidget(self.lbl_gc)
        info_row.addStretch()
        info_row.addWidget(self.lbl_status)
        layout.addLayout(info_row)

        self._mol = MoleculeType.RNA

    def set_molecule(self, mol: MoleculeType):
        self._mol = mol
        self._on_changed()

    def get_sequence(self) -> str:
        return clean_sequence(self.text_edit.toPlainText())

    def set_sequence(self, seq: str):
        self.text_edit.setPlainText(seq)

    def _on_changed(self):
        seq = self.get_sequence()
        self.lbl_len.setText(f"Length: {len(seq)}")
        if seq:
            self.lbl_gc.setText(f"GC: {gc_content(seq)*100:.1f}%")
            ok, msg = validate_sequence(seq, self._mol)
            self.lbl_status.setText("" if ok else msg)
        else:
            self.lbl_gc.setText("GC: —")
            self.lbl_status.setText("")
        self.sequence_changed.emit()


class ParamsPanel(QGroupBox):
    """Shared parameter controls: molecule type, temperature, salts."""

    def __init__(self, title: str = "Parameters", parent=None):
        super().__init__(title, parent)
        grid = QGridLayout(self)

        # Molecule type
        grid.addWidget(QLabel("Type:"), 0, 0)
        self.cmb_mol = QComboBox()
        self.cmb_mol.addItems(["RNA", "DNA"])
        grid.addWidget(self.cmb_mol, 0, 1)

        # Temperature
        grid.addWidget(QLabel("Temperature (°C):"), 1, 0)
        self.spn_temp = QDoubleSpinBox()
        self.spn_temp.setRange(0, 100)
        self.spn_temp.setValue(37.0)
        self.spn_temp.setSingleStep(1.0)
        self.spn_temp.setDecimals(1)
        grid.addWidget(self.spn_temp, 1, 1)

        # Na+
        grid.addWidget(QLabel("[Na⁺] (M):"), 2, 0)
        self.spn_na = QDoubleSpinBox()
        self.spn_na.setRange(0.0, 2.0)
        self.spn_na.setValue(1.0)
        self.spn_na.setSingleStep(0.05)
        self.spn_na.setDecimals(3)
        grid.addWidget(self.spn_na, 2, 1)

        # Mg2+
        grid.addWidget(QLabel("[Mg²⁺] (M):"), 3, 0)
        self.spn_mg = QDoubleSpinBox()
        self.spn_mg.setRange(0.0, 0.5)
        self.spn_mg.setValue(0.0)
        self.spn_mg.setSingleStep(0.001)
        self.spn_mg.setDecimals(4)
        grid.addWidget(self.spn_mg, 3, 1)

        grid.setColumnStretch(1, 1)

    def get_molecule(self) -> MoleculeType:
        return MoleculeType.RNA if self.cmb_mol.currentIndex() == 0 else MoleculeType.DNA

    def get_params(self) -> FoldingParams:
        return FoldingParams(
            temperature=self.spn_temp.value(),
            na_conc=self.spn_na.value(),
            mg_conc=self.spn_mg.value(),
            molecule=self.get_molecule(),
        )


class ResultText(QGroupBox):
    """Text output with copy button."""

    def __init__(self, title: str = "Results", parent=None):
        super().__init__(title, parent)
        layout = QVBoxLayout(self)
        self.text = QPlainTextEdit()
        self.text.setFont(MONO_FONT)
        self.text.setReadOnly(True)
        layout.addWidget(self.text)

        btn_row = QHBoxLayout()
        self.btn_copy = QPushButton("Copy")
        self.btn_copy.clicked.connect(self._copy)
        btn_row.addStretch()
        btn_row.addWidget(self.btn_copy)
        layout.addLayout(btn_row)

    def set_text(self, text: str):
        self.text.setPlainText(text)

    def append(self, text: str):
        self.text.appendPlainText(text)

    def clear(self):
        self.text.clear()

    def _copy(self):
        cb = QApplication.clipboard()
        if cb:
            cb.setText(self.text.toPlainText())


class RunButton(QWidget):
    """Run button + progress bar + cancel."""

    run_clicked = pyqtSignal()
    cancel_clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.btn_run = QPushButton("▶ Run")
        self.btn_run.setMinimumHeight(36)
        self.btn_run.setStyleSheet(
            "QPushButton { background-color: #2563eb; color: white; "
            "font-weight: bold; border-radius: 4px; padding: 6px 20px; }"
            "QPushButton:hover { background-color: #1d4ed8; }"
            "QPushButton:disabled { background-color: #93c5fd; }"
        )
        self.btn_run.clicked.connect(self.run_clicked.emit)
        layout.addWidget(self.btn_run)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setTextVisible(True)
        layout.addWidget(self.progress)

        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setVisible(False)
        self.btn_cancel.clicked.connect(self.cancel_clicked.emit)
        layout.addWidget(self.btn_cancel)

    def set_running(self, running: bool):
        self.btn_run.setEnabled(not running)
        self.progress.setVisible(running)
        self.btn_cancel.setVisible(running)
        if running:
            self.progress.setValue(0)

    def set_progress(self, current: int, total: int):
        self.progress.setMaximum(total)
        self.progress.setValue(current)


class ExportBar(QWidget):
    """Row of export buttons."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.btn_json = QPushButton("Export JSON")
        self.btn_csv = QPushButton("Export CSV")
        self.btn_png = QPushButton("Export PNG")
        self.btn_svg = QPushButton("Export SVG")

        for btn in (self.btn_json, self.btn_csv, self.btn_png, self.btn_svg):
            btn.setEnabled(False)
            layout.addWidget(btn)
        layout.addStretch()
