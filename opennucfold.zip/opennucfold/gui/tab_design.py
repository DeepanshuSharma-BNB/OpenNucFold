"""Tab 4 — Sequence Design: heuristic optimizer for target structures."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QLabel,
    QMessageBox, QFileDialog, QPushButton, QSpinBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QDoubleSpinBox,
    QGroupBox, QGridLayout, QLineEdit, QPlainTextEdit,
    QAbstractItemView, QTextEdit,
)

from opennucfold.backends.manager import BackendManager
from opennucfold.gui.widgets import ParamsPanel, RunButton, MONO_FONT
from opennucfold.gui.workers import DesignWorker
from opennucfold.core.designer import DesignConstraints
from opennucfold.models import (
    AnalysisReport, DesignResult, DesignCandidate, MoleculeType,
)
from opennucfold.utils.sequences import validate_dot_bracket


DEMO_TARGET = "((((....))))....((((....))))"


class DesignTab(QWidget):
    """Sequence design tab."""

    def __init__(self, backend_mgr: BackendManager, parent=None):
        super().__init__(parent)
        self.backend_mgr = backend_mgr
        self._worker = None
        self._result: DesignResult | None = None
        self._build_ui()

    def _build_ui(self):
        main = QHBoxLayout(self)

        # Left: inputs
        left = QVBoxLayout()

        # Target structure
        grp_target = QGroupBox("Target Structure")
        tgt_layout = QVBoxLayout(grp_target)
        self.target_edit = QLineEdit()
        self.target_edit.setFont(MONO_FONT)
        self.target_edit.setPlaceholderText("Dot-bracket: e.g. (((...)))...")
        tgt_layout.addWidget(self.target_edit)
        self.lbl_target_len = QLabel("Length: 0")
        tgt_layout.addWidget(self.lbl_target_len)
        self.target_edit.textChanged.connect(
            lambda: self.lbl_target_len.setText(f"Length: {len(self.target_edit.text().strip())}"))
        left.addWidget(grp_target)

        # Parameters
        self.params = ParamsPanel()
        left.addWidget(self.params)

        # Constraints
        grp_const = QGroupBox("Design Constraints")
        const_grid = QGridLayout(grp_const)

        const_grid.addWidget(QLabel("GC min:"), 0, 0)
        self.spn_gc_min = QDoubleSpinBox()
        self.spn_gc_min.setRange(0.0, 1.0)
        self.spn_gc_min.setValue(0.35)
        self.spn_gc_min.setSingleStep(0.05)
        self.spn_gc_min.setDecimals(2)
        const_grid.addWidget(self.spn_gc_min, 0, 1)

        const_grid.addWidget(QLabel("GC max:"), 0, 2)
        self.spn_gc_max = QDoubleSpinBox()
        self.spn_gc_max.setRange(0.0, 1.0)
        self.spn_gc_max.setValue(0.65)
        self.spn_gc_max.setSingleStep(0.05)
        self.spn_gc_max.setDecimals(2)
        const_grid.addWidget(self.spn_gc_max, 0, 3)

        const_grid.addWidget(QLabel("Max homopolymer:"), 1, 0)
        self.spn_homopoly = QSpinBox()
        self.spn_homopoly.setRange(2, 10)
        self.spn_homopoly.setValue(4)
        const_grid.addWidget(self.spn_homopoly, 1, 1)

        const_grid.addWidget(QLabel("Avoid motifs:"), 2, 0)
        self.motif_edit = QLineEdit("AAAA,CCCC,GGGG,UUUU")
        self.motif_edit.setToolTip("Comma-separated motifs to avoid")
        const_grid.addWidget(self.motif_edit, 2, 1, 1, 3)

        left.addWidget(grp_const)

        # Optimizer settings
        grp_opt = QGroupBox("Optimizer")
        opt_grid = QGridLayout(grp_opt)

        opt_grid.addWidget(QLabel("SA steps:"), 0, 0)
        self.spn_steps = QSpinBox()
        self.spn_steps.setRange(50, 5000)
        self.spn_steps.setValue(500)
        self.spn_steps.setSingleStep(100)
        opt_grid.addWidget(self.spn_steps, 0, 1)

        opt_grid.addWidget(QLabel("Restarts:"), 0, 2)
        self.spn_restarts = QSpinBox()
        self.spn_restarts.setRange(1, 50)
        self.spn_restarts.setValue(10)
        opt_grid.addWidget(self.spn_restarts, 0, 3)

        opt_grid.addWidget(QLabel("Top K:"), 1, 0)
        self.spn_topk = QSpinBox()
        self.spn_topk.setRange(1, 20)
        self.spn_topk.setValue(5)
        opt_grid.addWidget(self.spn_topk, 1, 1)

        left.addWidget(grp_opt)

        self.run_btn = RunButton()
        self.run_btn.run_clicked.connect(self._run)
        self.run_btn.cancel_clicked.connect(self._cancel)
        left.addWidget(self.run_btn)

        btn_demo = QPushButton("Load Demo Target")
        btn_demo.clicked.connect(lambda: self.target_edit.setText(DEMO_TARGET))
        left.addWidget(btn_demo)

        left.addStretch()

        btn_row = QHBoxLayout()
        self.btn_json = QPushButton("Export JSON")
        self.btn_json.setEnabled(False)
        self.btn_json.clicked.connect(self._export_json)
        self.btn_fasta = QPushButton("Export FASTA")
        self.btn_fasta.setEnabled(False)
        self.btn_fasta.clicked.connect(self._export_fasta)
        btn_row.addWidget(self.btn_json)
        btn_row.addWidget(self.btn_fasta)
        btn_row.addStretch()
        left.addLayout(btn_row)

        left_w = QWidget()
        left_w.setLayout(left)

        # Right: results
        right = QVBoxLayout()

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(
            ["Sequence", "Predicted Structure", "ΔG", "Match %", "GC %", "Score"])
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.currentCellChanged.connect(self._show_detail)
        right.addWidget(self.table)

        self.detail_text = QPlainTextEdit()
        self.detail_text.setReadOnly(True)
        self.detail_text.setFont(MONO_FONT)
        self.detail_text.setMaximumHeight(200)
        right.addWidget(QLabel("Candidate Detail:"))
        right.addWidget(self.detail_text)

        right_w = QWidget()
        right_w.setLayout(right)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_w)
        splitter.addWidget(right_w)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        main.addWidget(splitter)

    def _run(self):
        target = self.target_edit.text().strip()
        ok, msg = validate_dot_bracket(target)
        if not ok:
            QMessageBox.warning(self, "Invalid Target Structure", msg)
            return

        params = self.params.get_params()
        mol = params.molecule

        backend = self.backend_mgr.primary()
        if not backend:
            QMessageBox.critical(self, "No Backend",
                                 "No folding backend available.")
            return

        motifs = [m.strip() for m in self.motif_edit.text().split(",") if m.strip()]
        constraints = DesignConstraints(
            gc_min=self.spn_gc_min.value(),
            gc_max=self.spn_gc_max.value(),
            avoid_motifs=motifs,
            max_homopolymer=self.spn_homopoly.value(),
        )

        self.run_btn.set_running(True)
        self.table.setRowCount(0)
        self.detail_text.clear()

        self._worker = DesignWorker(
            target, mol, backend, params, constraints,
            n_candidates=self.spn_topk.value(),
            sa_steps=self.spn_steps.value(),
            n_restarts=self.spn_restarts.value(),
        )
        self._worker.progress.connect(self.run_btn.set_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _cancel(self):
        if self._worker:
            self._worker.cancel()
            self._worker.quit()
            self.run_btn.set_running(False)

    def _on_finished(self, result: DesignResult):
        self.run_btn.set_running(False)
        self._result = result

        self.table.setRowCount(len(result.candidates))
        for row, cand in enumerate(result.candidates):
            self.table.setItem(row, 0, QTableWidgetItem(cand.sequence))
            self.table.setItem(row, 1, QTableWidgetItem(cand.predicted_structure))
            self.table.setItem(row, 2, QTableWidgetItem(f"{cand.delta_g:.2f}"))
            self.table.setItem(row, 3, QTableWidgetItem(f"{cand.structure_match*100:.1f}"))
            self.table.setItem(row, 4, QTableWidgetItem(f"{cand.gc_content*100:.1f}"))
            self.table.setItem(row, 5, QTableWidgetItem(f"{cand.score:.3f}"))

        self.btn_json.setEnabled(True)
        self.btn_fasta.setEnabled(True)

    def _show_detail(self, row, col, prev_row, prev_col):
        if self._result and 0 <= row < len(self._result.candidates):
            cand = self._result.candidates[row]
            lines = [
                f"Sequence:   {cand.sequence}",
                f"Target:     {cand.target_structure}",
                f"Predicted:  {cand.predicted_structure}",
                f"ΔG:         {cand.delta_g:.2f} kcal/mol",
                f"Match:      {cand.structure_match*100:.1f}%",
                f"GC:         {cand.gc_content*100:.1f}%",
                f"Score:      {cand.score:.4f}",
            ]
            if cand.warnings:
                lines.append(f"\nWarnings: {'; '.join(cand.warnings)}")
            self.detail_text.setPlainText("\n".join(lines))

    def _on_error(self, msg: str):
        self.run_btn.set_running(False)
        QMessageBox.critical(self, "Design Error", msg)

    def _export_json(self):
        if not self._result:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save JSON Report", "design_report.json",
            "JSON Files (*.json)")
        if path:
            report = AnalysisReport("design", self._result)
            report.save(path)

    def _export_fasta(self):
        if not self._result:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export FASTA", "designed_sequences.fasta",
            "FASTA Files (*.fasta *.fa)")
        if path:
            with open(path, "w") as f:
                for i, cand in enumerate(self._result.candidates):
                    f.write(f">candidate_{i+1} dG={cand.delta_g:.2f} "
                            f"match={cand.structure_match*100:.0f}%\n")
                    f.write(f"{cand.sequence}\n")
