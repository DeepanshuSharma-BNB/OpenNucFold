"""Background worker threads for all analysis operations.

All heavy computations run in QThread workers to keep the GUI responsive.
Each worker emits progress/result/error signals.
"""

from __future__ import annotations

from PyQt6.QtCore import QThread, pyqtSignal

from opennucfold.backends.base import FoldingBackend
from opennucfold.models import (
    FoldingParams,
    SingleFoldResult,
    DuplexResult,
    MixtureResult,
    DesignResult,
    StrandInput,
    MoleculeType,
)
from opennucfold.core.mixture import run_mixture_analysis
from opennucfold.core.designer import run_design, DesignConstraints
from opennucfold.utils.parsers import estimate_tm_simple


class SingleFoldWorker(QThread):
    """Worker for single-strand MFE + partition function."""

    finished = pyqtSignal(object)  # SingleFoldResult
    error = pyqtSignal(str)
    progress = pyqtSignal(int, int)

    def __init__(self, sequence: str, params: FoldingParams,
                 backend: FoldingBackend, do_partition: bool = True):
        super().__init__()
        self.sequence = sequence
        self.params = params
        self.backend = backend
        self.do_partition = do_partition
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            self.progress.emit(0, 2)
            if self.do_partition:
                result = self.backend.partition_function(self.sequence, self.params)
            else:
                result = self.backend.fold_single(self.sequence, self.params)
            self.progress.emit(2, 2)
            if not self._cancelled:
                self.finished.emit(result)
        except Exception as e:
            if not self._cancelled:
                self.error.emit(str(e))


class DuplexWorker(QThread):
    """Worker for duplex / co-fold analysis."""

    finished = pyqtSignal(object)  # DuplexResult
    error = pyqtSignal(str)
    progress = pyqtSignal(int, int)

    def __init__(self, seq_a: str, seq_b: str, params: FoldingParams,
                 backend: FoldingBackend,
                 tm_backend: FoldingBackend = None):
        super().__init__()
        self.seq_a = seq_a
        self.seq_b = seq_b
        self.params = params
        self.backend = backend
        self.tm_backend = tm_backend
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            self.progress.emit(0, 4)

            # Self-fold A
            res_a = self.backend.fold_single(self.seq_a, self.params)
            self.progress.emit(1, 4)

            # Self-fold B
            res_b = self.backend.fold_single(self.seq_b, self.params)
            self.progress.emit(2, 4)

            # Co-fold
            cofold = self.backend.fold_cofold(self.seq_a, self.seq_b, self.params)
            self.progress.emit(3, 4)

            # Duplex
            try:
                dup = self.backend.duplex(self.seq_a, self.seq_b, self.params)
            except Exception:
                dup = {"structure": cofold.get("structure", ""),
                       "energy": cofold.get("energy", 0.0)}

            # Tm
            tm = None
            tm_method = ""
            if self.tm_backend:
                tm = self.tm_backend.estimate_tm(self.seq_a, self.seq_b, self.params)
                if tm is not None:
                    tm_method = f"{self.tm_backend.name}"
            if tm is None:
                # Fallback simple estimate
                tm = estimate_tm_simple(self.seq_a, self.params.na_conc)
                tm_method = "simple formula (fallback)"

            self.progress.emit(4, 4)

            result = DuplexResult(
                seq_a=self.seq_a,
                seq_b=self.seq_b,
                cofold_structure=cofold.get("structure", ""),
                cofold_energy=cofold.get("energy", 0.0),
                self_a_structure=res_a.mfe_structure,
                self_a_energy=res_a.mfe_energy,
                self_b_structure=res_b.mfe_structure,
                self_b_energy=res_b.mfe_energy,
                duplex_structure=dup.get("structure", ""),
                duplex_energy=dup.get("energy", 0.0),
                tm_estimate=tm,
                tm_method=tm_method,
                binding_favorable=(cofold.get("energy", 0.0) <
                                   min(res_a.mfe_energy, res_b.mfe_energy)),
                backend=self.backend.name,
                backend_version=self.backend.version(),
                params=self.params,
            )

            if not self._cancelled:
                self.finished.emit(result)
        except Exception as e:
            if not self._cancelled:
                self.error.emit(str(e))


class MixtureWorker(QThread):
    """Worker for multi-strand mixture analysis."""

    finished = pyqtSignal(object)  # MixtureResult
    error = pyqtSignal(str)
    progress = pyqtSignal(int, int)

    def __init__(self, strands: list[StrandInput], max_size: int,
                 params: FoldingParams, backend: FoldingBackend):
        super().__init__()
        self.strands = strands
        self.max_size = max_size
        self.params = params
        self.backend = backend
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            result = run_mixture_analysis(
                self.strands,
                self.max_size,
                self.backend,
                self.params,
                progress_callback=lambda c, t: self.progress.emit(c, t),
                cancel_check=lambda: self._cancelled,
            )
            if not self._cancelled:
                self.finished.emit(result)
        except Exception as e:
            if not self._cancelled:
                self.error.emit(str(e))


class DesignWorker(QThread):
    """Worker for sequence design."""

    finished = pyqtSignal(object)  # DesignResult
    error = pyqtSignal(str)
    progress = pyqtSignal(int, int)

    def __init__(self, target: str, mol: MoleculeType,
                 backend: FoldingBackend, params: FoldingParams,
                 constraints: DesignConstraints,
                 n_candidates: int = 5, sa_steps: int = 500,
                 n_restarts: int = 10):
        super().__init__()
        self.target = target
        self.mol = mol
        self.backend = backend
        self.params = params
        self.constraints = constraints
        self.n_candidates = n_candidates
        self.sa_steps = sa_steps
        self.n_restarts = n_restarts
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            result = run_design(
                self.target, self.mol, self.backend, self.params,
                self.constraints,
                n_candidates=self.n_candidates,
                sa_steps=self.sa_steps,
                n_restarts=self.n_restarts,
                progress_callback=lambda c, t: self.progress.emit(c, t),
                cancel_check=lambda: self._cancelled,
            )
            if not self._cancelled:
                self.finished.emit(result)
        except Exception as e:
            if not self._cancelled:
                self.error.emit(str(e))
