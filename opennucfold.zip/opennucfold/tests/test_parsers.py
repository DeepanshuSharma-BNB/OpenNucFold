"""Tests for opennucfold.utils.parsers."""

import pytest

from opennucfold.utils.parsers import (
    parse_rnafold_output,
    parse_rnafold_bpp,
    parse_rnacofold_output,
    parse_rnaduplex_output,
    parse_rnaeval_output,
    parse_unafold_ct,
    estimate_tm_simple,
)


# ---------------------------------------------------------------------------
# RNAfold
# ---------------------------------------------------------------------------

class TestParseRNAfold:
    def test_basic_mfe(self):
        text = "GGGAAACCC\n(((...))) ( -1.20)"
        result = parse_rnafold_output(text)
        assert result["sequence"] == "GGGAAACCC"
        assert result["mfe_structure"] == "(((...)))"
        assert result["mfe_energy"] == pytest.approx(-1.20)

    def test_with_partition(self):
        text = (
            "GGGAAACCC\n"
            "(((...))) ( -1.20)\n"
            "(((...))) [ -1.58]\n"
            " frequency of mfe structure in ensemble 0.6; ensemble diversity 2.34\n"
        )
        result = parse_rnafold_output(text)
        assert result["mfe_energy"] == pytest.approx(-1.20)
        assert result["ensemble_energy"] == pytest.approx(-1.58)
        assert result["ensemble_diversity"] == pytest.approx(2.34)

    def test_positive_energy(self):
        text = "AAAA\n.... (  0.00)"
        result = parse_rnafold_output(text)
        assert result["mfe_energy"] == pytest.approx(0.0)
        assert result["mfe_structure"] == "...."

    def test_too_short_raises(self):
        with pytest.raises(ValueError, match="too short"):
            parse_rnafold_output("GGGAAACCC")

    def test_bad_format_raises(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            parse_rnafold_output("GGGAAACCC\nnot a structure")


class TestParseBPP:
    def test_ubox_entries(self):
        ps_text = (
            "1 5 0.7071 ubox\n"
            "2 4 0.5000 ubox\n"
            "3 8 0.3162 ubox\n"
            "some other line\n"
        )
        bpp = parse_rnafold_bpp(ps_text)
        assert len(bpp) == 3
        assert bpp[0] == (1, 5, pytest.approx(0.5, abs=0.001))
        assert bpp[1] == (2, 4, pytest.approx(0.25, abs=0.001))
        assert bpp[2] == (3, 8, pytest.approx(0.1, abs=0.001))

    def test_empty(self):
        assert parse_rnafold_bpp("") == []
        assert parse_rnafold_bpp("no ubox here\njust text\n") == []


# ---------------------------------------------------------------------------
# RNAcofold
# ---------------------------------------------------------------------------

class TestParseRNAcofold:
    def test_basic(self):
        text = "GGGAAA&CCCUUU\n(((..&..))) (-3.40)"
        result = parse_rnacofold_output(text)
        assert result["sequence"] == "GGGAAA&CCCUUU"
        assert result["structure"] == "(((..&..)))"
        assert result["energy"] == pytest.approx(-3.40)

    def test_too_short_raises(self):
        with pytest.raises(ValueError):
            parse_rnacofold_output("GGGAAA&CCCUUU")


# ---------------------------------------------------------------------------
# RNAduplex
# ---------------------------------------------------------------------------

class TestParseRNAduplex:
    def test_standard_format(self):
        text = ".(((.&.))).  1,5 : 1,5 (-4.50)"
        result = parse_rnaduplex_output(text)
        assert result["energy"] == pytest.approx(-4.50)
        assert ".(((" in result["structure"]

    def test_energy_extraction_fallback(self):
        text = "some weird format (-2.10)"
        result = parse_rnaduplex_output(text)
        assert result["energy"] == pytest.approx(-2.10)

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="empty"):
            parse_rnaduplex_output("")


# ---------------------------------------------------------------------------
# RNAeval
# ---------------------------------------------------------------------------

class TestParseRNAeval:
    def test_standard(self):
        text = "GGGAAACCC\n(((...))) ( -1.20)"
        assert parse_rnaeval_output(text) == pytest.approx(-1.20)

    def test_fails_on_garbage(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            parse_rnaeval_output("no energy here")


# ---------------------------------------------------------------------------
# UNAFold CT
# ---------------------------------------------------------------------------

class TestParseCT:
    def test_basic_ct(self):
        ct = (
            "5  dG = -1.20  test\n"
            "1  G  0  2  5  1\n"
            "2  G  1  3  4  2\n"
            "3  A  2  4  0  3\n"
            "4  C  3  5  2  4\n"
            "5  C  4  0  1  5\n"
        )
        seq, pairs = parse_unafold_ct(ct)
        assert seq == "GGACC"
        assert (1, 5) in pairs
        assert (2, 4) in pairs
        assert len(pairs) == 2

    def test_empty(self):
        seq, pairs = parse_unafold_ct("")
        assert seq == ""
        assert pairs == []


# ---------------------------------------------------------------------------
# Tm estimate
# ---------------------------------------------------------------------------

class TestTmSimple:
    def test_short_oligo(self):
        # Wallace rule: 2*AT + 4*GC
        tm = estimate_tm_simple("GCGCGC")  # 6 bp, all GC
        assert tm == 24  # 2*0 + 4*6

    def test_long_oligo(self):
        seq = "GCATCGATCGATCGATCGATCG"
        tm = estimate_tm_simple(seq, na_conc=0.05)
        assert 50 < tm < 80  # reasonable range for 22-mer

    def test_all_at(self):
        tm = estimate_tm_simple("ATAT")  # 4 bp, all AT
        assert tm == 8  # 2*4 + 4*0
