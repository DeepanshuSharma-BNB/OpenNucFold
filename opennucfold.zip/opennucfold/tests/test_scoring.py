"""Tests for opennucfold.core.designer scoring functions."""

import pytest

from opennucfold.core.designer import (
    structure_match_score,
    homopolymer_penalty,
    motif_penalty,
    initialize_sequence,
    _random_pair,
)
from opennucfold.core.mixture import (
    enumerate_complexes,
    stoichiometry_label,
    boltzmann_weight,
)
from opennucfold.models import MoleculeType


# ---------------------------------------------------------------------------
# Designer scoring
# ---------------------------------------------------------------------------

class TestStructureMatch:
    def test_perfect_match(self):
        assert structure_match_score("(((...)))", "(((...)))") == pytest.approx(1.0)

    def test_no_match(self):
        assert structure_match_score(".........", "(((...)))") == pytest.approx(0.0, abs=0.2)

    def test_partial(self):
        score = structure_match_score("((....).)", "(((...)))")
        assert 0.0 < score < 1.0

    def test_different_lengths(self):
        assert structure_match_score("((..))", "((..))..") == 0.0


class TestHomopolymerPenalty:
    def test_no_penalty(self):
        assert homopolymer_penalty("ACGUACGU", max_len=4) == 0.0

    def test_penalty_for_5_run(self):
        p = homopolymer_penalty("AAAAACGU", max_len=4)
        assert p > 0.0

    def test_penalty_scales(self):
        p5 = homopolymer_penalty("AAAAACGU", max_len=4)
        p6 = homopolymer_penalty("AAAAAACGU", max_len=4)
        assert p6 > p5


class TestMotifPenalty:
    def test_no_motifs(self):
        assert motif_penalty("ACGUACGU", ["AAAA"]) == 0.0

    def test_one_motif(self):
        assert motif_penalty("AAAACGU", ["AAAA"]) == 1.0

    def test_two_occurrences(self):
        assert motif_penalty("AAAACGUAAAA", ["AAAA"]) == 2.0


class TestInitializeSequence:
    def test_length(self):
        target = "(((...)))"
        seq = initialize_sequence(target, MoleculeType.RNA)
        assert len(seq) == len(target)

    def test_all_valid_bases(self):
        target = "(((...)))"
        seq = initialize_sequence(target, MoleculeType.RNA)
        assert all(b in "ACGU" for b in seq)

    def test_dna_bases(self):
        target = "(((...)))"
        seq = initialize_sequence(target, MoleculeType.DNA)
        assert all(b in "ACGT" for b in seq)


class TestRandomPair:
    def test_rna_pair(self):
        for _ in range(20):
            b1, b2 = _random_pair(MoleculeType.RNA)
            assert b1 in "ACGU"
            assert b2 in "ACGU"

    def test_dna_pair(self):
        for _ in range(20):
            b1, b2 = _random_pair(MoleculeType.DNA)
            assert b1 in "ACGT"
            assert b2 in "ACGT"


# ---------------------------------------------------------------------------
# Mixture helpers
# ---------------------------------------------------------------------------

class TestEnumerateComplexes:
    def test_2_strands_dimers(self):
        combos = enumerate_complexes(2, 2)
        # monomers: (0,), (1,)
        # dimers: (0,0), (0,1), (1,1)
        assert (0,) in combos
        assert (1,) in combos
        assert (0, 0) in combos
        assert (0, 1) in combos
        assert (1, 1) in combos
        assert len(combos) == 5

    def test_3_strands_dimers(self):
        combos = enumerate_complexes(3, 2)
        # monomers: 3
        # dimers: combinations_with_replacement(3, 2) = 6
        assert len(combos) == 9

    def test_max_size_1(self):
        combos = enumerate_complexes(3, 1)
        assert len(combos) == 3  # just monomers


class TestStoichiometryLabel:
    def test_basic(self):
        assert stoichiometry_label((0, 1), ["A", "B"]) == "A + B"
        assert stoichiometry_label((0, 0), ["A", "B"]) == "A + A"
        assert stoichiometry_label((0,), ["A", "B"]) == "A"


class TestBoltzmannWeight:
    def test_negative_dg_favored(self):
        w1 = boltzmann_weight(-5.0, 37.0)
        w2 = boltzmann_weight(0.0, 37.0)
        assert w1 > w2

    def test_zero_dg(self):
        w = boltzmann_weight(0.0, 37.0)
        assert w == pytest.approx(1.0)

    def test_temperature_effect(self):
        # Higher T reduces weight difference
        w_low = boltzmann_weight(-5.0, 20.0)
        w_high = boltzmann_weight(-5.0, 80.0)
        assert w_low > w_high
