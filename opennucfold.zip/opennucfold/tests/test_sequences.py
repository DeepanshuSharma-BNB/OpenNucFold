"""Tests for opennucfold.utils.sequences."""

import pytest

from opennucfold.models import MoleculeType
from opennucfold.utils.sequences import (
    clean_sequence,
    validate_sequence,
    gc_content,
    rna_to_dna,
    dna_to_rna,
    reverse_complement,
    validate_dot_bracket,
    parse_pairs_from_dotbracket,
)


class TestCleanSequence:
    def test_removes_whitespace_and_numbers(self):
        assert clean_sequence("GGG AAA 123 CCC") == "GGGAAACCC"

    def test_strips_fasta_header(self):
        assert clean_sequence(">my seq\nGGGAAACCC\nUUU") == "GGGAAACCCUUU"

    def test_uppercases(self):
        assert clean_sequence("gggaaaccc") == "GGGAAACCC"

    def test_empty(self):
        assert clean_sequence("") == ""
        assert clean_sequence(">header only\n") == ""


class TestValidateSequence:
    def test_valid_rna(self):
        ok, msg = validate_sequence("GGGAAACCCUUU", MoleculeType.RNA)
        assert ok

    def test_valid_dna(self):
        ok, msg = validate_sequence("GGGAAACCCTTT", MoleculeType.DNA)
        assert ok

    def test_t_in_rna_strict(self):
        ok, msg = validate_sequence("GGGAAACCCTTT", MoleculeType.RNA, strict=True)
        assert not ok
        assert "T" in msg

    def test_u_in_dna_strict(self):
        ok, msg = validate_sequence("GGGAAACCCUUU", MoleculeType.DNA, strict=True)
        assert not ok

    def test_empty_invalid(self):
        ok, _ = validate_sequence("", MoleculeType.RNA)
        assert not ok

    def test_iupac_allowed_by_default(self):
        ok, _ = validate_sequence("GRYSWKMBDHVN", MoleculeType.RNA)
        assert ok

    def test_bad_chars(self):
        ok, msg = validate_sequence("GGG123CCC", MoleculeType.RNA, strict=True)
        assert not ok


class TestGCContent:
    def test_all_gc(self):
        assert gc_content("GCGCGC") == pytest.approx(1.0)

    def test_no_gc(self):
        assert gc_content("AAAUUU") == pytest.approx(0.0)

    def test_mixed(self):
        assert gc_content("AAGC") == pytest.approx(0.5)

    def test_empty(self):
        assert gc_content("") == pytest.approx(0.0)


class TestConversions:
    def test_rna_to_dna(self):
        assert rna_to_dna("GGGAAACCCUUU") == "GGGAAACCCTTT"

    def test_dna_to_rna(self):
        assert dna_to_rna("GGGAAACCCTTT") == "GGGAAACCCUUU"

    def test_reverse_complement_rna(self):
        assert reverse_complement("GGGAAACCC", MoleculeType.RNA) == "GGGUUUCCC"

    def test_reverse_complement_dna(self):
        assert reverse_complement("GGGAAACCC", MoleculeType.DNA) == "GGGTTTCCC"


class TestDotBracket:
    def test_valid(self):
        ok, _ = validate_dot_bracket("(((...)))")
        assert ok

    def test_unbalanced(self):
        ok, msg = validate_dot_bracket("(((...))")
        assert not ok
        assert "Unbalanced" in msg

    def test_wrong_length(self):
        ok, msg = validate_dot_bracket("(((.)))", seq_len=5)
        assert not ok

    def test_empty(self):
        ok, _ = validate_dot_bracket("")
        assert not ok

    def test_bad_chars(self):
        ok, _ = validate_dot_bracket("(((...)))x")
        assert not ok


class TestParsePairs:
    def test_simple(self):
        pairs = parse_pairs_from_dotbracket("(((...)))")
        assert (0, 8) in pairs
        assert (1, 7) in pairs
        assert (2, 6) in pairs
        assert len(pairs) == 3

    def test_no_pairs(self):
        assert parse_pairs_from_dotbracket("....") == []

    def test_nested(self):
        pairs = parse_pairs_from_dotbracket("((..))((..))")
        assert len(pairs) == 4
