"""OpenNucFold — application entry point."""

from __future__ import annotations

import os
import sys
import traceback


def _setup_high_dpi():
    """Enable high-DPI scaling on all platforms."""
    os.environ.setdefault("QT_AUTO_SCREEN_SCALE_FACTOR", "1")


def _light_stylesheet() -> str:
    """Return a clean, light scientific theme stylesheet."""
    return """
    QMainWindow, QWidget {
        font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
        font-size: 13px;
    }
    QTabWidget::pane {
        border: 1px solid #d1d5db;
        border-radius: 4px;
    }
    QTabBar::tab {
        padding: 8px 20px;
        margin-right: 2px;
        border: 1px solid #d1d5db;
        border-bottom: none;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
        background: #f3f4f6;
    }
    QTabBar::tab:selected {
        background: white;
        font-weight: bold;
    }
    QGroupBox {
        font-weight: bold;
        border: 1px solid #e5e7eb;
        border-radius: 6px;
        margin-top: 12px;
        padding-top: 16px;
    }
    QGroupBox::title {
        subcontrol-origin: margin;
        left: 10px;
        padding: 0 4px;
    }
    QPlainTextEdit, QTextEdit, QLineEdit {
        border: 1px solid #d1d5db;
        border-radius: 4px;
        padding: 4px;
        background: white;
    }
    QPlainTextEdit:focus, QTextEdit:focus, QLineEdit:focus {
        border-color: #2563eb;
    }
    QTableWidget {
        gridline-color: #e5e7eb;
        border: 1px solid #d1d5db;
        border-radius: 4px;
    }
    QHeaderView::section {
        background: #f9fafb;
        border: none;
        border-bottom: 1px solid #d1d5db;
        padding: 6px;
        font-weight: bold;
    }
    QProgressBar {
        border: 1px solid #d1d5db;
        border-radius: 4px;
        text-align: center;
        height: 20px;
    }
    QProgressBar::chunk {
        background-color: #2563eb;
        border-radius: 3px;
    }
    QPushButton {
        padding: 5px 14px;
        border: 1px solid #d1d5db;
        border-radius: 4px;
        background: #f9fafb;
    }
    QPushButton:hover {
        background: #e5e7eb;
    }
    QPushButton:disabled {
        color: #9ca3af;
    }
    QStatusBar {
        border-top: 1px solid #e5e7eb;
    }
    QSplitter::handle {
        background: #e5e7eb;
        width: 2px;
        height: 2px;
    }
    """


def _exception_hook(exc_type, exc_value, exc_tb):
    """Global exception handler — shows dialog instead of crashing."""
    msg = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    sys.stderr.write(msg)
    try:
        from PyQt6.QtWidgets import QMessageBox
        QMessageBox.critical(
            None, "Unexpected Error",
            f"An unexpected error occurred:\n\n{exc_value}\n\n"
            "See terminal for full traceback.")
    except Exception:
        pass


def main():
    _setup_high_dpi()
    sys.excepthook = _exception_hook

    from PyQt6.QtWidgets import QApplication
    from opennucfold.gui.main_window import MainWindow

    app = QApplication(sys.argv)
    app.setApplicationName("OpenNucFold")
    app.setApplicationVersion("1.0.0")
    app.setStyle("Fusion")
    app.setStyleSheet(_light_stylesheet())

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
