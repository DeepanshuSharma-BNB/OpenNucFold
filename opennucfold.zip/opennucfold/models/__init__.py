"""Data models for folding results, analysis parameters, and reports."""

from __future__ import annotations

import json
import platform
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Optional


class MoleculeType(str, Enum):
    RNA = "RNA"
    DNA = "DNA"


@dataclass
class FoldingParams:
    """Shared parameters for any folding calculation."""
    temperature: float = 37.0          # °C
    na_conc: float = 1.0               # M  (monovalent cation)
    mg_conc: float = 0.0               # M  (divalent cation, if supported)
    molecule: MoleculeType = MoleculeType.RNA
    constraints: str = ""              # dot-bracket constraint string
    dangles: int = 2                   # 0, 1, or 2


@dataclass
class SingleFoldResult:
    """Result from single-strand MFE + partition function."""
    sequence: str = ""
    mfe_structure: str = ""
    mfe_energy: float = 0.0            # kcal/mol
    ensemble_energy: float = 0.0       # kcal/mol
    ensemble_diversity: float = 0.0
    base_pair_probs: Optional[list] = None   # list of (i, j, prob)
    positional_entropy: Optional[list] = None
    pairing_probs: Optional[list] = None     # per-base pairing probability
    backend: str = ""
    backend_version: str = ""
    params: Optional[FoldingParams] = None
    raw_output: str = ""


@dataclass
class DuplexResult:
    """Result from co-folding / duplex analysis."""
    seq_a: str = ""
    seq_b: str = ""
    cofold_structure: str = ""
    cofold_energy: float = 0.0         # kcal/mol
    self_a_structure: str = ""
    self_a_energy: float = 0.0
    self_b_structure: str = ""
    self_b_energy: float = 0.0
    duplex_structure: str = ""
    duplex_energy: float = 0.0
    tm_estimate: Optional[float] = None    # °C
    tm_method: str = ""
    binding_favorable: bool = False
    backend: str = ""
    backend_version: str = ""
    params: Optional[FoldingParams] = None
    raw_output: str = ""


@dataclass
class StrandInput:
    """A strand in a mixture analysis."""
    name: str = ""
    sequence: str = ""
    concentration: float = 0.0         # µM


@dataclass
class ComplexResult:
    """One predicted complex in a mixture."""
    strand_names: list = field(default_factory=list)
    strand_indices: list = field(default_factory=list)
    stoichiometry: str = ""
    structure: str = ""
    delta_g: float = 0.0               # kcal/mol
    fraction: float = 0.0
    concentration: float = 0.0         # µM


@dataclass
class MixtureResult:
    """Multi-strand mixture analysis result."""
    strands: list = field(default_factory=list)      # list of StrandInput
    complexes: list = field(default_factory=list)     # list of ComplexResult
    max_complex_size: int = 2
    warnings: list = field(default_factory=list)
    backend: str = ""
    backend_version: str = ""
    params: Optional[FoldingParams] = None


@dataclass
class DesignCandidate:
    """One candidate from the design engine."""
    sequence: str = ""
    predicted_structure: str = ""
    target_structure: str = ""
    delta_g: float = 0.0
    structure_match: float = 0.0       # fraction of bp matching target
    gc_content: float = 0.0
    self_dimer_energy: float = 0.0
    score: float = 0.0                 # composite objective
    warnings: list = field(default_factory=list)


@dataclass
class DesignResult:
    """Result from the design engine."""
    target_structure: str = ""
    candidates: list = field(default_factory=list)   # list of DesignCandidate
    params: dict = field(default_factory=dict)
    backend: str = ""
    backend_version: str = ""


class AnalysisReport:
    """JSON-serializable analysis report for reproducibility."""

    def __init__(self, analysis_type: str, result, params: FoldingParams = None):
        self.timestamp = datetime.now().isoformat()
        self.app_version = "1.0.0"
        self.os_info = f"{platform.system()} {platform.release()}"
        self.python_version = platform.python_version()
        self.analysis_type = analysis_type
        self.params = asdict(params) if params else {}
        self.result = self._serialize(result)

    @staticmethod
    def _serialize(obj):
        if hasattr(obj, '__dataclass_fields__'):
            d = asdict(obj)
            # Remove raw_output for cleanliness (optional)
            return d
        if isinstance(obj, list):
            return [AnalysisReport._serialize(x) for x in obj]
        return obj

    def to_json(self, indent: int = 2) -> str:
        return json.dumps({
            "app": "OpenNucFold",
            "version": self.app_version,
            "timestamp": self.timestamp,
            "os": self.os_info,
            "python": self.python_version,
            "analysis_type": self.analysis_type,
            "parameters": self.params,
            "result": self.result,
        }, indent=indent, default=str)

    def save(self, path: str):
        with open(path, 'w') as f:
            f.write(self.to_json())
