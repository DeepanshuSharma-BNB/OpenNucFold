"""Backend manager: detects available folding tools and selects the best
backend for each operation.
"""

from __future__ import annotations

from typing import Optional

from opennucfold.backends.base import FoldingBackend
from opennucfold.backends.vienna import ViennaRNABackend
from opennucfold.backends.unafold import UNAFoldBackend
from opennucfold.models import FoldingParams, MoleculeType


class BackendManager:
    """Registry of folding backends.  Detects availability at startup."""

    def __init__(self):
        self.backends: dict[str, FoldingBackend] = {}
        self._register_defaults()

    def _register_defaults(self):
        for cls in (ViennaRNABackend, UNAFoldBackend):
            b = cls()
            self.backends[b.name] = b

    def refresh(self):
        """Re-probe backend availability (e.g. after PATH change)."""
        self._register_defaults()

    def available(self) -> dict[str, str]:
        """Return {name: version} for installed backends."""
        return {
            name: b.version()
            for name, b in self.backends.items()
            if b.is_available()
        }

    def status_text(self) -> str:
        """Human-readable backend availability summary."""
        lines = []
        for name, b in self.backends.items():
            if b.is_available():
                lines.append(f"✓ {name} {b.version()}")
            else:
                lines.append(f"✗ {name}  (not found)")
        return "\n".join(lines)

    def get(self, name: str) -> Optional[FoldingBackend]:
        b = self.backends.get(name)
        if b and b.is_available():
            return b
        return None

    @property
    def vienna(self) -> Optional[ViennaRNABackend]:
        return self.get("ViennaRNA")

    @property
    def unafold(self) -> Optional[UNAFoldBackend]:
        return self.get("UNAFold")

    def primary(self) -> Optional[FoldingBackend]:
        """Return the primary (preferred) available backend."""
        return self.vienna or self.unafold or None

    def best_for_duplex(self, params: FoldingParams) -> Optional[FoldingBackend]:
        """Pick the best backend for duplex / Tm calculations."""
        if params.molecule == MoleculeType.DNA and self.unafold:
            return self.unafold
        return self.primary()

    def can_estimate_tm(self, params: FoldingParams) -> bool:
        if self.unafold:
            return True
        return False
