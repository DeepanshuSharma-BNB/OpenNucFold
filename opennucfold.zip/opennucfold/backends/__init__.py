"""Pluggable folding-engine backends."""

from opennucfold.backends.manager import BackendManager

__all__ = ["BackendManager"]
