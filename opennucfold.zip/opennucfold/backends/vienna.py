"""ViennaRNA backend wrapper.

Wraps command-line tools: RNAfold, RNAcofold, RNAduplex, RNAeval.
Uses subprocess with timeouts and stderr capture.
Prefers machine-readable output flags where available.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from typing import Optional

from opennucfold.backends.base import FoldingBackend
from opennucfold.models import FoldingParams, SingleFoldResult, MoleculeType
from opennucfold.utils.parsers import (
    parse_rnafold_output,
    parse_rnafold_bpp,
    parse_rnacofold_output,
    parse_rnaduplex_output,
    parse_rnaeval_output,
)

_TIMEOUT = 300  # seconds


class ViennaRNABackend(FoldingBackend):
    """Backend wrapping ViennaRNA command-line tools."""

    name = "ViennaRNA"

    def __init__(self):
        self._version_cache: Optional[str] = None

    # ------------------------------------------------------------------
    # Availability
    # ------------------------------------------------------------------

    def is_available(self) -> bool:
        return shutil.which("RNAfold") is not None

    def version(self) -> str:
        if self._version_cache is not None:
            return self._version_cache
        try:
            proc = subprocess.run(
                ["RNAfold", "--version"],
                capture_output=True, text=True, timeout=10
            )
            out = (proc.stdout + proc.stderr).strip()
            # "RNAfold 2.6.4" or just "2.6.4"
            self._version_cache = out.split()[-1] if out else "unknown"
        except Exception:
            self._version_cache = ""
        return self._version_cache

    def supports_dna(self) -> bool:
        # ViennaRNA supports DNA parameters via -P dna_mathews2004.par
        return True

    def supports_salt(self) -> bool:
        # ViennaRNA ≥ 2.6 has --salt; older versions do not
        v = self.version()
        try:
            major, minor = (int(x) for x in v.split(".")[:2])
            return (major, minor) >= (2, 6)
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _base_args(self, params: FoldingParams) -> list[str]:
        """Build common CLI flags from FoldingParams."""
        args = ["-T", str(params.temperature), "-d", str(params.dangles)]
        if params.molecule == MoleculeType.DNA:
            # Use DNA parameter file shipped with ViennaRNA
            dna_par = self._find_dna_par()
            if dna_par:
                args += ["-P", dna_par]
        if params.na_conc != 1.0 and self.supports_salt():
            args += ["--salt", str(params.na_conc)]
        return args

    @staticmethod
    def _find_dna_par() -> str:
        """Try to locate the DNA parameter file."""
        candidates = [
            "/usr/share/ViennaRNA/dna_mathews2004.par",
            "/usr/local/share/ViennaRNA/dna_mathews2004.par",
        ]
        # Also check VIENNARNA_PARAMS env
        env_dir = os.environ.get("VIENNAPAR", "")
        if env_dir:
            candidates.insert(0, os.path.join(env_dir, "dna_mathews2004.par"))
        for p in candidates:
            if os.path.isfile(p):
                return p
        return ""

    def _run(self, cmd: list[str], stdin_text: str = "",
             timeout: int = _TIMEOUT) -> subprocess.CompletedProcess:
        """Run a subprocess, raising descriptive errors."""
        try:
            proc = subprocess.run(
                cmd,
                input=stdin_text,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except FileNotFoundError:
            raise RuntimeError(f"Tool not found: {cmd[0]}. Is ViennaRNA installed?")
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"{cmd[0]} timed out after {timeout}s.")

        if proc.returncode != 0:
            msg = proc.stderr.strip() or proc.stdout.strip()
            raise RuntimeError(f"{cmd[0]} failed (exit {proc.returncode}): {msg[:500]}")
        return proc

    # ------------------------------------------------------------------
    # Interface implementation
    # ------------------------------------------------------------------

    def fold_single(self, sequence: str, params: FoldingParams) -> SingleFoldResult:
        cmd = ["RNAfold", "--noPS"] + self._base_args(params)
        if params.constraints:
            cmd.append("-C")
            stdin = f"{sequence}\n{params.constraints}\n"
        else:
            stdin = sequence + "\n"

        proc = self._run(cmd, stdin)
        parsed = parse_rnafold_output(proc.stdout)

        return SingleFoldResult(
            sequence=parsed["sequence"],
            mfe_structure=parsed["mfe_structure"],
            mfe_energy=parsed["mfe_energy"],
            backend=self.name,
            backend_version=self.version(),
            params=params,
            raw_output=proc.stdout,
        )

    def partition_function(self, sequence: str, params: FoldingParams) -> SingleFoldResult:
        # Run with -p to get partition function and dot plot
        tmpdir = tempfile.mkdtemp(prefix="onf_")
        try:
            cmd = ["RNAfold", "-p", "--MEA"] + self._base_args(params)
            if params.constraints:
                cmd.append("-C")
                stdin = f"{sequence}\n{params.constraints}\n"
            else:
                stdin = sequence + "\n"

            proc = self._run(cmd, stdin)
            parsed = parse_rnafold_output(proc.stdout)

            result = SingleFoldResult(
                sequence=parsed["sequence"],
                mfe_structure=parsed["mfe_structure"],
                mfe_energy=parsed["mfe_energy"],
                ensemble_energy=parsed.get("ensemble_energy", 0.0) or 0.0,
                ensemble_diversity=parsed.get("ensemble_diversity", 0.0) or 0.0,
                backend=self.name,
                backend_version=self.version(),
                params=params,
                raw_output=proc.stdout,
            )

            # Try to read dot-plot file for base-pair probabilities
            dp_candidates = [
                os.path.join(os.getcwd(), "dot.ps"),
                os.path.join(os.getcwd(), f"{sequence[:10]}_dp.ps"),
                os.path.join(tmpdir, "dot.ps"),
            ]
            # Also look for generic filenames
            for f in os.listdir(os.getcwd()):
                if f.endswith("_dp.ps"):
                    dp_candidates.insert(0, os.path.join(os.getcwd(), f))

            for dp_path in dp_candidates:
                if os.path.isfile(dp_path):
                    try:
                        with open(dp_path) as fh:
                            bpp = parse_rnafold_bpp(fh.read())
                        result.base_pair_probs = bpp
                        # Per-base pairing probability
                        n = len(sequence)
                        pp = [0.0] * n
                        for i, j, p in bpp:
                            if 1 <= i <= n:
                                pp[i - 1] += p
                            if 1 <= j <= n:
                                pp[j - 1] += p
                        result.pairing_probs = [min(1.0, x) for x in pp]
                    except Exception:
                        pass
                    finally:
                        try:
                            os.remove(dp_path)
                        except OSError:
                            pass
                    break

            # Clean up any .ps files generated
            for f in os.listdir(os.getcwd()):
                if f.endswith(".ps") and ("dot" in f or "_dp" in f or "_ss" in f):
                    try:
                        os.remove(os.path.join(os.getcwd(), f))
                    except OSError:
                        pass

            return result
        finally:
            try:
                shutil.rmtree(tmpdir, ignore_errors=True)
            except Exception:
                pass

    def fold_cofold(self, seq_a: str, seq_b: str, params: FoldingParams) -> dict:
        cmd = ["RNAcofold", "--noPS"] + self._base_args(params)
        stdin = f"{seq_a}&{seq_b}\n"
        proc = self._run(cmd, stdin)
        return parse_rnacofold_output(proc.stdout)

    def duplex(self, seq_a: str, seq_b: str, params: FoldingParams) -> dict:
        cmd = ["RNAduplex"] + self._base_args(params)
        stdin = f"{seq_a}\n{seq_b}\n"
        proc = self._run(cmd, stdin)
        return parse_rnaduplex_output(proc.stdout)

    def eval_structure(self, sequence: str, structure: str,
                       params: FoldingParams) -> float:
        cmd = ["RNAeval"] + self._base_args(params)
        stdin = f"{sequence}\n{structure}\n"
        proc = self._run(cmd, stdin)
        return parse_rnaeval_output(proc.stdout)

    def estimate_tm(self, seq_a: str, seq_b: str,
                    params: FoldingParams) -> Optional[float]:
        """ViennaRNA doesn't compute Tm directly — return None."""
        return None
