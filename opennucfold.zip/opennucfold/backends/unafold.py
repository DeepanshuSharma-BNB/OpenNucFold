"""UNAFold backend wrapper.

Provides DNA duplex thermodynamics and Tm calculations via
hybrid-ss-min and hybrid-min (hybrid-2s) command-line tools.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from typing import Optional

from opennucfold.backends.base import FoldingBackend
from opennucfold.models import FoldingParams, SingleFoldResult, MoleculeType
from opennucfold.utils.parsers import parse_unafold_ct, estimate_tm_simple

_TIMEOUT = 120


class UNAFoldBackend(FoldingBackend):
    """Backend wrapping UNAFold (mfold-family) tools."""

    name = "UNAFold"

    def __init__(self):
        self._version_cache: Optional[str] = None

    def is_available(self) -> bool:
        return shutil.which("hybrid-ss-min") is not None

    def version(self) -> str:
        if self._version_cache is not None:
            return self._version_cache
        try:
            proc = subprocess.run(
                ["hybrid-ss-min", "--version"],
                capture_output=True, text=True, timeout=10
            )
            out = (proc.stdout + proc.stderr).strip()
            self._version_cache = out.split()[-1] if out else "unknown"
        except Exception:
            self._version_cache = ""
        return self._version_cache

    def supports_dna(self) -> bool:
        return True

    def supports_salt(self) -> bool:
        return True

    def _na_arg(self, params: FoldingParams) -> list[str]:
        args = ["--NA", "DNA" if params.molecule == MoleculeType.DNA else "RNA"]
        args += ["--sodium", str(params.na_conc)]
        if params.mg_conc > 0:
            args += ["--magnesium", str(params.mg_conc)]
        args += ["--temperature", str(params.temperature)]
        return args

    def _run(self, cmd, stdin_text="", timeout=_TIMEOUT, cwd=None):
        try:
            proc = subprocess.run(
                cmd,
                input=stdin_text,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )
        except FileNotFoundError:
            raise RuntimeError(f"Tool not found: {cmd[0]}. Is UNAFold installed?")
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"{cmd[0]} timed out after {timeout}s.")
        if proc.returncode != 0:
            msg = proc.stderr.strip() or proc.stdout.strip()
            raise RuntimeError(f"{cmd[0]} failed (exit {proc.returncode}): {msg[:500]}")
        return proc

    # ------------------------------------------------------------------
    # Single strand (hybrid-ss-min)
    # ------------------------------------------------------------------

    def fold_single(self, sequence: str, params: FoldingParams) -> SingleFoldResult:
        tmpdir = tempfile.mkdtemp(prefix="onf_una_")
        seq_file = os.path.join(tmpdir, "input.seq")
        try:
            with open(seq_file, "w") as f:
                f.write(f">input\n{sequence}\n")

            cmd = ["hybrid-ss-min"] + self._na_arg(params) + [seq_file]
            self._run(cmd, cwd=tmpdir)

            # Read .ct file
            ct_file = os.path.join(tmpdir, "input.ct")
            if not os.path.isfile(ct_file):
                # Try alternative naming
                for fn in os.listdir(tmpdir):
                    if fn.endswith(".ct"):
                        ct_file = os.path.join(tmpdir, fn)
                        break

            seq_out, pairs = "", []
            energy = 0.0
            if os.path.isfile(ct_file):
                with open(ct_file) as fh:
                    ct_text = fh.read()
                seq_out, pairs = parse_unafold_ct(ct_text)
                # Extract energy from header
                import re
                em = re.search(r'dG\s*=\s*([+-]?\d+\.?\d*)', ct_text)
                if em:
                    energy = float(em.group(1))

            # Convert pairs to dot-bracket
            n = len(sequence)
            db = list("." * n)
            for i, j in pairs:
                if 1 <= i <= n and 1 <= j <= n:
                    db[i - 1] = "("
                    db[j - 1] = ")"

            return SingleFoldResult(
                sequence=sequence,
                mfe_structure="".join(db),
                mfe_energy=energy,
                backend=self.name,
                backend_version=self.version(),
                params=params,
                raw_output=ct_text if os.path.isfile(ct_file) else "",
            )
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def partition_function(self, sequence: str, params: FoldingParams) -> SingleFoldResult:
        # UNAFold doesn't directly output BPP in the same way — fall back to fold
        result = self.fold_single(sequence, params)
        result.ensemble_energy = result.mfe_energy  # approximation
        return result

    # ------------------------------------------------------------------
    # Duplex (hybrid-min / hybrid-2s)
    # ------------------------------------------------------------------

    def fold_cofold(self, seq_a: str, seq_b: str, params: FoldingParams) -> dict:
        return self._run_hybrid2(seq_a, seq_b, params)

    def duplex(self, seq_a: str, seq_b: str, params: FoldingParams) -> dict:
        return self._run_hybrid2(seq_a, seq_b, params)

    def _run_hybrid2(self, seq_a: str, seq_b: str, params: FoldingParams) -> dict:
        tmpdir = tempfile.mkdtemp(prefix="onf_una2_")
        fa = os.path.join(tmpdir, "a.seq")
        fb = os.path.join(tmpdir, "b.seq")
        try:
            with open(fa, "w") as f:
                f.write(f">a\n{seq_a}\n")
            with open(fb, "w") as f:
                f.write(f">b\n{seq_b}\n")

            tool = "hybrid-min"
            if not shutil.which(tool):
                tool = "hybrid-2s"

            cmd = [tool] + self._na_arg(params) + [fa, fb]
            self._run(cmd, cwd=tmpdir)

            # Read results
            energy = 0.0
            import re
            for fn in os.listdir(tmpdir):
                fpath = os.path.join(tmpdir, fn)
                if fn.endswith(".ct") or fn.endswith(".dG"):
                    with open(fpath) as fh:
                        txt = fh.read()
                    em = re.search(r'dG\s*=\s*([+-]?\d+\.?\d*)', txt)
                    if em:
                        energy = float(em.group(1))
                        break

            return {"structure": "", "energy": energy}
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def estimate_tm(self, seq_a: str, seq_b: str,
                    params: FoldingParams) -> Optional[float]:
        """Use UNAFold's hybrid-min with temperature scan, or fallback."""
        # Simple approach: use the built-in Tm from hybrid tools
        tmpdir = tempfile.mkdtemp(prefix="onf_tm_")
        fa = os.path.join(tmpdir, "a.seq")
        fb = os.path.join(tmpdir, "b.seq")
        try:
            with open(fa, "w") as f:
                f.write(f">a\n{seq_a}\n")
            with open(fb, "w") as f:
                f.write(f">b\n{seq_b}\n")

            tool = "hybrid-min"
            if not shutil.which(tool):
                tool = "hybrid-2s"
            if not shutil.which(tool):
                return estimate_tm_simple(seq_a, params.na_conc)

            cmd = [tool, "--NA",
                   "DNA" if params.molecule == MoleculeType.DNA else "RNA",
                   "--sodium", str(params.na_conc),
                   "--tmin", "20", "--tmax", "95", "--tinc", "1",
                   fa, fb]
            self._run(cmd, cwd=tmpdir)

            import re
            for fn in os.listdir(tmpdir):
                if "dG" in fn or fn.endswith(".ens"):
                    with open(os.path.join(tmpdir, fn)) as fh:
                        txt = fh.read()
                    m = re.search(r'Tm\s*=\s*([+-]?\d+\.?\d*)', txt, re.IGNORECASE)
                    if m:
                        return float(m.group(1))

            return None
        except Exception:
            return None
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
