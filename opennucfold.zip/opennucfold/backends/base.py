"""Abstract base class defining the folding backend interface.

Every backend (ViennaRNA, UNAFold, RNAstructure) must implement this
interface.  Methods that a backend does not support should raise
NotImplementedError with a clear message.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional, Tuple

from opennucfold.models import FoldingParams, SingleFoldResult, DuplexResult


class FoldingBackend(ABC):
    """Interface that all folding backends must implement."""

    name: str = "AbstractBackend"

    @abstractmethod
    def is_available(self) -> bool:
        """Return True if the backend executables are found on PATH."""
        ...

    @abstractmethod
    def version(self) -> str:
        """Return the backend version string, or '' if unavailable."""
        ...

    @abstractmethod
    def fold_single(self, sequence: str, params: FoldingParams) -> SingleFoldResult:
        """MFE fold of a single strand.  Must populate at minimum:
        mfe_structure, mfe_energy."""
        ...

    @abstractmethod
    def partition_function(self, sequence: str, params: FoldingParams) -> SingleFoldResult:
        """Partition function calculation — must populate base_pair_probs,
        ensemble_energy, and ensemble_diversity when possible."""
        ...

    @abstractmethod
    def fold_cofold(self, seq_a: str, seq_b: str, params: FoldingParams) -> dict:
        """Co-fold two strands.  Returns dict with keys:
        structure, energy."""
        ...

    @abstractmethod
    def duplex(self, seq_a: str, seq_b: str, params: FoldingParams) -> dict:
        """Quick duplex prediction (may differ from cofold).
        Returns dict with keys: structure, energy."""
        ...

    def eval_structure(self, sequence: str, structure: str, params: FoldingParams) -> float:
        """Evaluate the free energy of a given structure.
        Not all backends may support this; default raises NotImplementedError."""
        raise NotImplementedError(f"{self.name} does not support eval_structure.")

    def estimate_tm(self, seq_a: str, seq_b: str, params: FoldingParams) -> Optional[float]:
        """Return Tm in °C, or None if not supported."""
        return None

    def supports_dna(self) -> bool:
        """Whether this backend has DNA parameters."""
        return False

    def supports_salt(self) -> bool:
        """Whether Na+/Mg2+ salt corrections are supported."""
        return False
