"""OpenNucFold — open-source nucleic acid folding & design toolkit."""

__version__ = "1.0.0"
