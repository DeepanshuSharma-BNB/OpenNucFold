"""Multi-strand mixture analysis (NUPACK-like approximation).

This module enumerates candidate complexes (up to a user-specified maximum
size), computes ΔG for each via ViennaRNA cofold, then estimates
equilibrium concentrations using simplified mass-action / Boltzmann
weighting.

⚠ DISCLAIMER:  This is an *approximate* method.  It does not perform full
   partition-function enumeration over all secondary structures of all
   possible complexes, as NUPACK does.  Results should be treated as
   order-of-magnitude estimates useful for screening, not quantitative
   thermodynamic predictions.
"""

from __future__ import annotations

import itertools
import math
from typing import Callable, Optional

from opennucfold.backends.base import FoldingBackend
from opennucfold.models import (
    FoldingParams,
    StrandInput,
    ComplexResult,
    MixtureResult,
)

R = 1.987e-3  # kcal/(mol·K)


def enumerate_complexes(n_strands: int, max_size: int) -> list[tuple[int, ...]]:
    """Return all multisets of strand indices up to *max_size*.

    Each element is a sorted tuple of strand indices (0-based), e.g.
    (0,), (1,), (0, 0), (0, 1), (1, 1), (0, 0, 1), …
    """
    indices = list(range(n_strands))
    combos: list[tuple[int, ...]] = []
    for size in range(1, max_size + 1):
        combos.extend(itertools.combinations_with_replacement(indices, size))
    return combos


def stoichiometry_label(combo: tuple[int, ...], names: list[str]) -> str:
    """Human-readable stoichiometry string, e.g. 'A + B', 'A + A'."""
    parts = [names[i] for i in combo]
    return " + ".join(parts)


def cofold_energy(
    combo: tuple[int, ...],
    sequences: list[str],
    backend: FoldingBackend,
    params: FoldingParams,
) -> tuple[float, str]:
    """Estimate ΔG of a complex via iterative cofold.

    For monomers, uses fold_single.
    For dimers, uses fold_cofold.
    For trimers+, chains pairwise cofolds (rough approximation).
    """
    seqs = [sequences[i] for i in combo]

    if len(seqs) == 1:
        res = backend.fold_single(seqs[0], params)
        return res.mfe_energy, res.mfe_structure

    if len(seqs) == 2:
        res = backend.fold_cofold(seqs[0], seqs[1], params)
        return res["energy"], res.get("structure", "")

    # For 3+ strands, approximate by iterative cofold:
    # fold (s1&s2), then cofold result with s3, etc.
    combined = seqs[0]
    struct = ""
    total_energy = 0.0
    for s in seqs[1:]:
        res = backend.fold_cofold(combined, s, params)
        total_energy = res["energy"]  # ViennaRNA cofold gives total ΔG
        struct = res.get("structure", "")
        combined = combined + "&" + s  # keep track

    return total_energy, struct


def boltzmann_weight(delta_g: float, temperature_c: float) -> float:
    """Boltzmann factor exp(-ΔG / RT)."""
    T = temperature_c + 273.15
    return math.exp(-delta_g / (R * T))


def run_mixture_analysis(
    strands: list[StrandInput],
    max_complex_size: int,
    backend: FoldingBackend,
    params: FoldingParams,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> MixtureResult:
    """Run the approximate mixture analysis.

    Parameters
    ----------
    strands : list of StrandInput
    max_complex_size : 2–4
    backend : a FoldingBackend
    params : FoldingParams (temperature, salts, etc.)
    progress_callback : optional (current, total) → None
    cancel_check : optional () → bool; return True to abort

    Returns
    -------
    MixtureResult
    """
    warnings: list[str] = [
        "⚠ Approximate method: complex concentrations are estimated via "
        "Boltzmann weighting of cofold ΔG values, NOT full partition-function "
        "enumeration.  Treat results as qualitative screening."
    ]

    names = [s.name or f"S{i+1}" for i, s in enumerate(strands)]
    sequences = [s.sequence for s in strands]
    concentrations = [s.concentration for s in strands]  # µM

    combos = enumerate_complexes(len(strands), max_complex_size)
    total = len(combos)

    raw_complexes: list[dict] = []

    for idx, combo in enumerate(combos):
        if cancel_check and cancel_check():
            warnings.append("Analysis cancelled by user.")
            break
        if progress_callback:
            progress_callback(idx, total)

        try:
            dg, struct = cofold_energy(combo, sequences, backend, params)
        except Exception as e:
            warnings.append(f"Failed to evaluate {stoichiometry_label(combo, names)}: {e}")
            continue

        raw_complexes.append({
            "combo": combo,
            "dg": dg,
            "structure": struct,
            "stoich": stoichiometry_label(combo, names),
        })

    if progress_callback:
        progress_callback(total, total)

    # --- Boltzmann weighting ---
    T_c = params.temperature
    weights = []
    for c in raw_complexes:
        # Scale by the product of input concentrations (mass-action)
        conc_product = 1.0
        for i in c["combo"]:
            conc_product *= concentrations[i]  # µM

        bw = boltzmann_weight(c["dg"], T_c) * conc_product
        weights.append(bw)

    total_weight = sum(weights) if weights else 1.0

    complexes: list[ComplexResult] = []
    for c, w in zip(raw_complexes, weights):
        frac = w / total_weight if total_weight > 0 else 0.0
        # Estimate concentration: fraction × average input concentration
        avg_conc = sum(concentrations) / len(concentrations) if concentrations else 0.0
        est_conc = frac * avg_conc

        complexes.append(ComplexResult(
            strand_names=[names[i] for i in c["combo"]],
            strand_indices=list(c["combo"]),
            stoichiometry=c["stoich"],
            structure=c["structure"],
            delta_g=c["dg"],
            fraction=frac,
            concentration=est_conc,
        ))

    # Sort by fraction descending
    complexes.sort(key=lambda x: x.fraction, reverse=True)

    # Warn about cross-talk
    for cx in complexes:
        if len(set(cx.strand_indices)) > 1 and cx.fraction > 0.05:
            warnings.append(
                f"Cross-talk detected: {cx.stoichiometry} at "
                f"{cx.fraction*100:.1f}% — check for undesired binding."
            )

    return MixtureResult(
        strands=strands,
        complexes=complexes,
        max_complex_size=max_complex_size,
        warnings=warnings,
        backend=backend.name,
        backend_version=backend.version(),
        params=params,
    )
