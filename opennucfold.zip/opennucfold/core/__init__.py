"""Core analysis engines: mixture model, sequence designer, report generation."""
