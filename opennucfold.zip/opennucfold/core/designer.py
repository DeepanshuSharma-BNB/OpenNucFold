"""Sequence design engine using simulated annealing.

Given a target secondary structure (dot-bracket), this module proposes
nucleotide sequences that fold into (or close to) that structure,
subject to user constraints (GC content, motif avoidance, etc.).

The optimizer uses simulated annealing with a composite score function
that balances structure match, ΔG, GC content, and off-target penalties.
"""

from __future__ import annotations

import math
import random
import re
from dataclasses import dataclass, field
from typing import Callable, Optional

from opennucfold.backends.base import FoldingBackend
from opennucfold.models import (
    FoldingParams,
    MoleculeType,
    DesignCandidate,
    DesignResult,
)
from opennucfold.utils.sequences import (
    gc_content,
    parse_pairs_from_dotbracket,
    validate_dot_bracket,
)


@dataclass
class DesignConstraints:
    """User-specified design constraints."""
    gc_min: float = 0.35
    gc_max: float = 0.65
    avoid_motifs: list[str] = field(default_factory=lambda: ["AAAA", "CCCC", "GGGG", "TTTT", "UUUU"])
    max_homopolymer: int = 4
    max_self_dimer_dg: float = -5.0   # kcal/mol — penalize if stronger
    blacklist_seqs: list[str] = field(default_factory=list)
    target_dg: Optional[float] = None  # optional target ΔG


@dataclass
class _SAState:
    """Internal state for simulated annealing."""
    sequence: list[str]
    score: float = 0.0
    structure: str = ""
    delta_g: float = 0.0
    match_frac: float = 0.0


# Nucleotide alphabets
_RNA_BASES = "ACGU"
_DNA_BASES = "ACGT"


def _random_base(mol: MoleculeType) -> str:
    return random.choice(_RNA_BASES if mol == MoleculeType.RNA else _DNA_BASES)


def _complement(base: str, mol: MoleculeType) -> str:
    if mol == MoleculeType.RNA:
        table = {"A": "U", "U": "A", "G": "C", "C": "G"}
    else:
        table = {"A": "T", "T": "A", "G": "C", "C": "G"}
    return table.get(base, _random_base(mol))


def _random_pair(mol: MoleculeType) -> tuple[str, str]:
    """Return a random Watson-Crick pair."""
    pairs = [("G", "C"), ("C", "G"), ("A", "U"), ("U", "A")] if mol == MoleculeType.RNA \
        else [("G", "C"), ("C", "G"), ("A", "T"), ("T", "A")]
    # Add GU wobble for RNA
    if mol == MoleculeType.RNA:
        pairs += [("G", "U"), ("U", "G")]
    return random.choice(pairs)


def initialize_sequence(target: str, mol: MoleculeType) -> list[str]:
    """Create an initial sequence compatible with target structure."""
    pairs = parse_pairs_from_dotbracket(target)
    seq = [_random_base(mol) for _ in range(len(target))]
    for i, j in pairs:
        b1, b2 = _random_pair(mol)
        seq[i] = b1
        seq[j] = b2
    return seq


def structure_match_score(predicted: str, target: str) -> float:
    """Fraction of positions where predicted structure matches target."""
    if len(predicted) != len(target):
        return 0.0
    matches = sum(1 for a, b in zip(predicted, target) if a == b)
    return matches / len(target)


def homopolymer_penalty(seq: str, max_len: int = 4) -> float:
    """Penalty for homopolymer runs exceeding max_len."""
    penalty = 0.0
    for base in "ACGTU":
        for m in re.finditer(f"{base}{{{max_len + 1},}}", seq):
            penalty += (len(m.group()) - max_len) * 0.5
    return penalty


def motif_penalty(seq: str, motifs: list[str]) -> float:
    """Penalty for each occurrence of forbidden motifs."""
    penalty = 0.0
    for motif in motifs:
        start = 0
        while True:
            idx = seq.find(motif, start)
            if idx == -1:
                break
            penalty += 1.0
            start = idx + 1
    return penalty


def compute_score(
    sequence: str,
    target: str,
    backend: FoldingBackend,
    params: FoldingParams,
    constraints: DesignConstraints,
) -> tuple[float, str, float, float]:
    """Compute composite score for a candidate sequence.

    Returns (score, predicted_structure, delta_g, match_fraction).
    Lower score is BETTER.
    """
    # Fold
    try:
        result = backend.fold_single(sequence, params)
        predicted = result.mfe_structure
        dg = result.mfe_energy
    except Exception:
        return 1e6, "", 0.0, 0.0

    # Structure match (maximize → minimize 1 - match)
    match = structure_match_score(predicted, target)
    score = (1.0 - match) * 10.0  # heavy weight on structure match

    # GC content penalty
    gc = gc_content(sequence)
    if gc < constraints.gc_min:
        score += (constraints.gc_min - gc) * 5.0
    elif gc > constraints.gc_max:
        score += (gc - constraints.gc_max) * 5.0

    # Homopolymer penalty
    score += homopolymer_penalty(sequence, constraints.max_homopolymer)

    # Motif penalty
    score += motif_penalty(sequence, constraints.avoid_motifs)

    # Target ΔG penalty
    if constraints.target_dg is not None:
        score += abs(dg - constraints.target_dg) * 0.2

    return score, predicted, dg, match


def mutate(seq: list[str], target: str, mol: MoleculeType, n_mutations: int = 1) -> list[str]:
    """Apply random point mutations respecting base-pairing in target."""
    new = seq[:]
    pairs = parse_pairs_from_dotbracket(target)
    pair_map = {}
    for i, j in pairs:
        pair_map[i] = j
        pair_map[j] = i

    for _ in range(n_mutations):
        pos = random.randint(0, len(new) - 1)
        if pos in pair_map:
            # Mutate as a pair
            b1, b2 = _random_pair(mol)
            partner = pair_map[pos]
            if pos < partner:
                new[pos] = b1
                new[partner] = b2
            else:
                new[pos] = b2
                new[partner] = b1
        else:
            new[pos] = _random_base(mol)
    return new


def run_design(
    target_structure: str,
    mol: MoleculeType,
    backend: FoldingBackend,
    params: FoldingParams,
    constraints: DesignConstraints,
    n_candidates: int = 5,
    sa_steps: int = 500,
    sa_temp_start: float = 5.0,
    sa_temp_end: float = 0.01,
    n_restarts: int = 10,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> DesignResult:
    """Run simulated annealing sequence design.

    Parameters
    ----------
    target_structure : dot-bracket
    mol : RNA or DNA
    backend : folding backend
    params : folding parameters
    constraints : design constraints
    n_candidates : number of top candidates to return
    sa_steps : SA iterations per restart
    sa_temp_start / sa_temp_end : SA temperature schedule
    n_restarts : number of independent SA runs
    progress_callback : (current_step, total_steps) → None
    cancel_check : () → bool

    Returns
    -------
    DesignResult with top candidates
    """
    total_steps = n_restarts * sa_steps
    current_step = 0
    all_candidates: list[_SAState] = []

    for restart in range(n_restarts):
        if cancel_check and cancel_check():
            break

        # Initialize
        seq = initialize_sequence(target_structure, mol)
        score, struct, dg, match = compute_score(
            "".join(seq), target_structure, backend, params, constraints
        )
        state = _SAState(seq, score, struct, dg, match)

        best = _SAState(seq[:], score, struct, dg, match)

        for step in range(sa_steps):
            if cancel_check and cancel_check():
                break

            current_step += 1
            if progress_callback and current_step % 10 == 0:
                progress_callback(current_step, total_steps)

            # Temperature schedule (exponential)
            frac = step / max(sa_steps - 1, 1)
            T = sa_temp_start * (sa_temp_end / sa_temp_start) ** frac

            # Mutate
            n_mut = max(1, int(3 * (1 - frac)))  # more mutations early
            new_seq = mutate(state.sequence, target_structure, mol, n_mut)
            new_score, new_struct, new_dg, new_match = compute_score(
                "".join(new_seq), target_structure, backend, params, constraints
            )

            # Accept?
            delta = new_score - state.score
            if delta < 0 or random.random() < math.exp(-delta / max(T, 1e-10)):
                state = _SAState(new_seq, new_score, new_struct, new_dg, new_match)

            if state.score < best.score:
                best = _SAState(state.sequence[:], state.score,
                                state.structure, state.delta_g, state.match_frac)

        all_candidates.append(best)

    # Sort by score and deduplicate
    all_candidates.sort(key=lambda s: s.score)
    seen = set()
    unique: list[_SAState] = []
    for c in all_candidates:
        seq_str = "".join(c.sequence)
        if seq_str not in seen:
            seen.add(seq_str)
            unique.append(c)

    # Build output
    candidates: list[DesignCandidate] = []
    for s in unique[:n_candidates]:
        seq_str = "".join(s.sequence)
        warnings = []
        if s.match_frac < 1.0:
            warnings.append(f"Structure match: {s.match_frac*100:.0f}%")
        gc = gc_content(seq_str)
        if gc < constraints.gc_min or gc > constraints.gc_max:
            warnings.append(f"GC content {gc*100:.1f}% outside target range")

        candidates.append(DesignCandidate(
            sequence=seq_str,
            predicted_structure=s.structure,
            target_structure=target_structure,
            delta_g=s.delta_g,
            structure_match=s.match_frac,
            gc_content=gc,
            score=s.score,
            warnings=warnings,
        ))

    if progress_callback:
        progress_callback(total_steps, total_steps)

    return DesignResult(
        target_structure=target_structure,
        candidates=candidates,
        params={
            "molecule": mol.value,
            "sa_steps": sa_steps,
            "n_restarts": n_restarts,
            "gc_range": [constraints.gc_min, constraints.gc_max],
        },
        backend=backend.name,
        backend_version=backend.version(),
    )
