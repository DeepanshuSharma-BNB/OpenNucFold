"""Utility modules for sequence handling and output parsing."""
