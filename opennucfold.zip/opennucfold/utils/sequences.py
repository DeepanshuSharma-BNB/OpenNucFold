"""Sequence validation, conversion, and analysis utilities."""

from __future__ import annotations

import re
from typing import Tuple

from opennucfold.models import MoleculeType

_RNA_BASES = set("ACGU")
_DNA_BASES = set("ACGT")
_IUPAC_RNA = set("ACGURYMKSWHBVDN")
_IUPAC_DNA = set("ACGTRYMKSWHBVDN")


def clean_sequence(seq: str) -> str:
    """Remove whitespace, numbers, and FASTA header lines."""
    lines = seq.strip().splitlines()
    cleaned = []
    for line in lines:
        line = line.strip()
        if line.startswith(">"):
            continue
        line = re.sub(r"[\s\d]", "", line)
        cleaned.append(line.upper())
    return "".join(cleaned)


def validate_sequence(seq: str, mol: MoleculeType, strict: bool = False) -> Tuple[bool, str]:
    """Validate a nucleic acid sequence.

    Returns (is_valid, message).
    """
    if not seq:
        return False, "Sequence is empty."
    if len(seq) > 50_000:
        return False, f"Sequence too long ({len(seq)} nt). Maximum 50,000."
    allowed = _RNA_BASES if mol == MoleculeType.RNA else _DNA_BASES
    if not strict:
        allowed = _IUPAC_RNA if mol == MoleculeType.RNA else _IUPAC_DNA
    bad = set(seq.upper()) - allowed
    if bad:
        return False, f"Invalid characters for {mol.value}: {', '.join(sorted(bad))}"
    return True, "OK"


def gc_content(seq: str) -> float:
    """Return GC fraction (0–1)."""
    seq = seq.upper()
    if not seq:
        return 0.0
    gc = sum(1 for c in seq if c in "GC")
    return gc / len(seq)


def rna_to_dna(seq: str) -> str:
    return seq.upper().replace("U", "T")


def dna_to_rna(seq: str) -> str:
    return seq.upper().replace("T", "U")


def complement(seq: str, mol: MoleculeType) -> str:
    if mol == MoleculeType.RNA:
        table = str.maketrans("ACGU", "UGCA")
    else:
        table = str.maketrans("ACGT", "TGCA")
    return seq.upper().translate(table)


def reverse_complement(seq: str, mol: MoleculeType) -> str:
    return complement(seq, mol)[::-1]


def validate_dot_bracket(db: str, seq_len: int = 0) -> Tuple[bool, str]:
    """Validate a dot-bracket structure string."""
    if not db:
        return False, "Structure is empty."
    allowed = set(".()")
    bad = set(db) - allowed
    if bad:
        return False, f"Invalid characters in structure: {', '.join(sorted(bad))}"
    if db.count("(") != db.count(")"):
        return False, "Unbalanced parentheses."
    if seq_len and len(db) != seq_len:
        return False, f"Structure length ({len(db)}) ≠ sequence length ({seq_len})."
    # Check nesting
    depth = 0
    for c in db:
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        if depth < 0:
            return False, "Unbalanced parentheses (closing without opening)."
    return True, "OK"


def parse_pairs_from_dotbracket(db: str) -> list:
    """Return list of (i, j) base pairs from dot-bracket."""
    stack = []
    pairs = []
    for i, c in enumerate(db):
        if c == "(":
            stack.append(i)
        elif c == ")":
            if stack:
                j = stack.pop()
                pairs.append((j, i))
    return sorted(pairs)
