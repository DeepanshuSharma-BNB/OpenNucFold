"""Parsers for ViennaRNA and UNAFold command-line tool outputs.

Each parser is designed to be robust against minor formatting changes and
returns structured data.  All parsers include explicit error handling.
"""

from __future__ import annotations

import re
from typing import Tuple, Optional


# ---------------------------------------------------------------------------
# ViennaRNA parsers
# ---------------------------------------------------------------------------

def parse_rnafold_output(text: str) -> dict:
    """Parse RNAfold stdout.

    Expected format (MFE only):
        SEQUENCE
        STRUCTURE (ENERGY)

    With -p (partition function):
        SEQUENCE
        STRUCTURE (ENERGY)
        STRUCTURE [ENSEMBLE_ENERGY]
        frequency of mfe structure ... ensemble diversity VALUE
    """
    result = {
        "sequence": "",
        "mfe_structure": "",
        "mfe_energy": 0.0,
        "ensemble_energy": None,
        "ensemble_diversity": None,
    }
    lines = [l.rstrip() for l in text.strip().splitlines() if l.strip()]
    if len(lines) < 2:
        raise ValueError(f"RNAfold output too short ({len(lines)} lines):\n{text[:300]}")

    result["sequence"] = lines[0].strip()

    # MFE line: structure (energy)
    mfe_match = re.match(r'^([.()\[\]{}]+)\s+\(\s*([+-]?\d+\.?\d*)\s*\)', lines[1])
    if not mfe_match:
        raise ValueError(f"Cannot parse MFE line: {lines[1]}")
    result["mfe_structure"] = mfe_match.group(1)
    result["mfe_energy"] = float(mfe_match.group(2))

    # Partition function line (optional)
    if len(lines) >= 3:
        ens_match = re.match(r'^[.()\[\]{}]+\s+\[\s*([+-]?\d+\.?\d*)\s*\]', lines[2])
        if ens_match:
            result["ensemble_energy"] = float(ens_match.group(1))

    # Ensemble diversity (optional)
    for line in lines:
        div_match = re.search(r'ensemble diversity\s+([+-]?\d+\.?\d*)', line)
        if div_match:
            result["ensemble_diversity"] = float(div_match.group(1))
            break

    return result


def parse_rnafold_bpp(dp_file_text: str) -> list:
    """Parse a ViennaRNA *_dp.ps or base-pair probability file.

    Looks for lines of the form:  i j sqrt_prob ubox
    Returns list of (i, j, probability).
    """
    pairs = []
    for line in dp_file_text.splitlines():
        line = line.strip()
        m = re.match(r'^(\d+)\s+(\d+)\s+([0-9.eE+-]+)\s+ubox', line)
        if m:
            i, j = int(m.group(1)), int(m.group(2))
            sqp = float(m.group(3))
            pairs.append((i, j, sqp * sqp))  # stored as sqrt(p) in .ps
    return pairs


def parse_rnacofold_output(text: str) -> dict:
    """Parse RNAcofold stdout.

    Format:
        SEQA&SEQB
        STRUCTURE (ENERGY)
    """
    result = {
        "sequence": "",
        "structure": "",
        "energy": 0.0,
    }
    lines = [l.rstrip() for l in text.strip().splitlines() if l.strip()]
    if len(lines) < 2:
        raise ValueError(f"RNAcofold output too short:\n{text[:300]}")

    result["sequence"] = lines[0].strip()

    mfe_match = re.match(r'^([.()\[\]{}&]+)\s+\(\s*([+-]?\d+\.?\d*)\s*\)', lines[1])
    if not mfe_match:
        raise ValueError(f"Cannot parse cofold MFE line: {lines[1]}")
    result["structure"] = mfe_match.group(1)
    result["energy"] = float(mfe_match.group(2))
    return result


def parse_rnaduplex_output(text: str) -> dict:
    """Parse RNAduplex stdout.

    Format:
        .(((.&.))).  i,j : k,l (ENERGY)
    """
    result = {"structure": "", "energy": 0.0, "positions": ""}
    lines = [l.rstrip() for l in text.strip().splitlines() if l.strip()]
    if not lines:
        raise ValueError("RNAduplex: empty output")

    # Try the standard format
    m = re.match(
        r'^([.()\[\]{}&]+)\s+([\d,]+\s*:\s*[\d,]+)\s+\(\s*([+-]?\d+\.?\d*)\s*\)',
        lines[-1]
    )
    if m:
        result["structure"] = m.group(1)
        result["positions"] = m.group(2)
        result["energy"] = float(m.group(3))
    else:
        # Fallback: look for energy anywhere
        for line in reversed(lines):
            em = re.search(r'\(\s*([+-]?\d+\.?\d*)\s*\)', line)
            if em:
                result["energy"] = float(em.group(1))
                result["structure"] = line.split()[0] if line.split() else ""
                break
    return result


def parse_rnaeval_output(text: str) -> float:
    """Parse RNAeval stdout — returns energy in kcal/mol.

    Format:
        SEQUENCE
        STRUCTURE ( ENERGY)
    """
    for line in reversed(text.strip().splitlines()):
        m = re.search(r'\(\s*([+-]?\d+\.?\d*)\s*\)', line)
        if m:
            return float(m.group(1))
    raise ValueError(f"Cannot parse RNAeval energy from:\n{text[:300]}")


# ---------------------------------------------------------------------------
# UNAFold parsers
# ---------------------------------------------------------------------------

def parse_unafold_hybrid_output(text: str) -> dict:
    """Parse UNAFold hybrid-ss-min or hybrid-min (hybrid-2s) .ct or .dG output."""
    result = {"energy": None, "tm": None, "structure": ""}

    # Look for dG value
    for line in text.splitlines():
        dg_match = re.search(r'dG\s*=\s*([+-]?\d+\.?\d*)', line, re.IGNORECASE)
        if dg_match:
            result["energy"] = float(dg_match.group(1))
        tm_match = re.search(r'Tm\s*=\s*([+-]?\d+\.?\d*)', line, re.IGNORECASE)
        if tm_match:
            result["tm"] = float(tm_match.group(1))

    return result


def parse_unafold_ct(ct_text: str) -> Tuple[str, list]:
    """Parse a .ct (connect table) file → (sequence, [(i,j),...]).

    CT format:
        N  dG = VALUE  title
        i  base  i-1  i+1  j  i
    where j=0 means unpaired.
    """
    lines = [l.strip() for l in ct_text.strip().splitlines() if l.strip()]
    if not lines:
        return "", []

    header = lines[0].split()
    n = int(header[0])
    seq_chars = []
    pairs = []
    for line in lines[1: n + 1]:
        parts = line.split()
        if len(parts) < 6:
            continue
        idx = int(parts[0])
        base = parts[1]
        partner = int(parts[4])
        seq_chars.append(base)
        if partner > idx:
            pairs.append((idx, partner))
    return "".join(seq_chars), pairs


# ---------------------------------------------------------------------------
# Tm estimation from nearest-neighbor (simple fallback)
# ---------------------------------------------------------------------------

def estimate_tm_simple(seq: str, na_conc: float = 0.05, strand_conc: float = 2.5e-7) -> float:
    """Rough Tm estimate using the simple formula (for short oligos ≤ 20 nt)
    and salt-adjusted for longer ones.  This is a *fallback* when UNAFold is unavailable.

    Uses the Wallace rule for very short seqs and a salt-adjusted basic formula
    for longer ones.  NOT a substitute for proper nearest-neighbor calculations.
    """
    seq = seq.upper().replace("U", "T")
    n = len(seq)
    gc = sum(1 for c in seq if c in "GC")

    if n < 14:
        # Wallace rule
        at = n - gc
        return 2 * at + 4 * gc
    else:
        # Basic salt-adjusted formula (Owczarzy et al. approximation)
        gc_frac = gc / n
        tm = 81.5 + 16.6 * (max(0, __import__('math').log10(na_conc))) + 41.0 * gc_frac - 600.0 / n
        return round(tm, 1)
